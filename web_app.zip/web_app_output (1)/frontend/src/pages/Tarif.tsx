import React from "react";
import { TableBlock } from "../components/runtime/TableBlock";

const Tarif: React.FC = () => {
  return (
    <div id="page-tarif-8">
    <div id="iqgkyx" style={{"display": "flex", "height": "100vh", "fontFamily": "Arial, sans-serif", "--chart-color-palette": "default"}}>
      <nav id="i2jb67" style={{"width": "250px", "background": "linear-gradient(135deg, #4b3c82 0%, #5a3d91 100%)", "color": "white", "padding": "20px", "overflowY": "auto", "display": "flex", "flexDirection": "column", "--chart-color-palette": "default"}}>
        <h2 id="iez00n" style={{"marginTop": "0", "fontSize": "24px", "marginBottom": "30px", "fontWeight": "bold", "--chart-color-palette": "default"}}>{"BESSER"}</h2>
        <div id="ikpi7x" style={{"display": "flex", "flexDirection": "column", "flex": "1", "--chart-color-palette": "default"}}>
          <a id="ieiahx" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "transparent", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/reservation">{"Reservation"}</a>
          <a id="ij5fbh" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "transparent", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/salle">{"Salle"}</a>
          <a id="in3ptn" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "transparent", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/centrecongres">{"CentreCongres"}</a>
          <a id="ibef72" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "transparent", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/gestionnaire">{"Gestionnaire"}</a>
          <a id="izv9ql" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "transparent", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/evenement">{"Evenement"}</a>
          <a id="ixzijl" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "transparent", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/ressource">{"Ressource"}</a>
          <a id="iclmwu" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "transparent", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/materiel">{"Materiel"}</a>
          <a id="ittc7e" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "transparent", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/prestation">{"Prestation"}</a>
          <a id="isynpt" style={{"color": "white", "textDecoration": "none", "padding": "10px 15px", "display": "block", "background": "rgba(255,255,255,0.2)", "borderRadius": "4px", "marginBottom": "5px", "--chart-color-palette": "default"}} href="/tarif">{"Tarif"}</a>
        </div>
        <p id="issiuk" style={{"marginTop": "auto", "paddingTop": "20px", "borderTop": "1px solid rgba(255,255,255,0.2)", "fontSize": "11px", "opacity": "0.8", "textAlign": "center", "--chart-color-palette": "default"}}>{"© 2026 BESSER. All rights reserved."}</p>
      </nav>
      <main id="ia3gli" style={{"flex": "1", "padding": "40px", "overflowY": "auto", "background": "#f5f5f5", "--chart-color-palette": "default"}}>
        <h1 id="iwp3ab" style={{"marginTop": "0", "color": "#333", "fontSize": "32px", "marginBottom": "10px", "--chart-color-palette": "default"}}>{"Tarif"}</h1>
        <p id="itczvs" style={{"color": "#666", "marginBottom": "30px", "--chart-color-palette": "default"}}>{"Manage Tarif data"}</p>
        <TableBlock id="table-tarif-8" styles={{"width": "100%", "minHeight": "400px", "--chart-color-palette": "default"}} title="Tarif List" options={{"showHeader": true, "stripedRows": false, "showPagination": true, "rowsPerPage": 5, "actionButtons": true, "columns": [{"label": "NomSaison", "column_type": "field", "field": "nomSaison", "type": "str", "required": true}, {"label": "PrixUnitaire", "column_type": "field", "field": "prixUnitaire", "type": "int", "required": true}, {"label": "Unite", "column_type": "field", "field": "unite", "type": "str", "required": true}, {"label": "DateDebutSaison", "column_type": "field", "field": "dateDebutSaison", "type": "date", "required": true}, {"label": "DateFinSaison", "column_type": "field", "field": "dateFinSaison", "type": "date", "required": true}], "formColumns": [{"column_type": "field", "field": "nomSaison", "label": "nomSaison", "type": "str", "required": true, "defaultValue": null}, {"column_type": "field", "field": "prixUnitaire", "label": "prixUnitaire", "type": "int", "required": true, "defaultValue": null}, {"column_type": "field", "field": "unite", "label": "unite", "type": "str", "required": true, "defaultValue": null}, {"column_type": "field", "field": "dateDebutSaison", "label": "dateDebutSaison", "type": "date", "required": true, "defaultValue": null}, {"column_type": "field", "field": "dateFinSaison", "label": "dateFinSaison", "type": "date", "required": true, "defaultValue": null}, {"column_type": "lookup", "path": "ressource_1", "field": "ressource_1", "lookup_field": "nom", "entity": "Ressource", "type": "list", "required": true}, {"column_type": "lookup", "path": "reservation_4", "field": "reservation_4", "lookup_field": "dateDebut", "entity": "Reservation", "type": "list", "required": false}, {"column_type": "lookup", "path": "salle_2", "field": "salle_2", "lookup_field": "nom", "entity": "Salle", "type": "list", "required": false}]}} dataBinding={{"entity": "Tarif", "endpoint": "/tarif/"}} />
        <div id="i65pl5" style={{"marginTop": "20px", "display": "flex", "gap": "10px", "flexWrap": "wrap", "--chart-color-palette": "default"}} />
      </main>
    </div>    </div>
  );
};

export default Tarif;
