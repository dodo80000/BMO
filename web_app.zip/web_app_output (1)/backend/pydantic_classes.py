from datetime import datetime, date, time
from typing import Any, List, Optional, Union, Set
from enum import Enum
from pydantic import BaseModel, field_validator

from abc import ABC, abstractmethod

############################################
# Enumerations are defined here
############################################

############################################
# Classes are defined here
############################################
class TarifCreate(BaseModel):
    nomSaison: str
    prixUnitaire: int
    dateFinSaison: date
    dateDebutSaison: date
    unite: str
    salle_2: Optional[List[int]] = None  # 1:N Relationship
    ressource_1: Optional[List[int]] = None  # 1:N Relationship
    reservation_4: Optional[List[int]] = None  # 1:N Relationship


class RessourceCreate(ABC, BaseModel):
    prix: int
    type: str
    stockMax: int
    nom: str
    tarif: int  # N:1 Relationship (mandatory)
    reservation_1: Optional[int] = None  # N:1 Relationship (optional)


class MaterielCreate(RessourceCreate):
    pass


class PrestationCreate(RessourceCreate):
    pass


class EvenementCreate(BaseModel):
    statistique: str
    nom: str
    nbParticipants: int
    emailreferent: str
    description: str
    reservation: int  # N:1 Relationship (mandatory)
    gestionnaire_1: Optional[List[int]] = None  # 1:N Relationship


class GestionnaireCreate(BaseModel):
    attribut: str
    evenement_1: int  # N:1 Relationship (mandatory)
    reservation_3: Optional[List[int]] = None  # 1:N Relationship
    centrecongres: int  # N:1 Relationship (mandatory)


class CentreCongresCreate(BaseModel):
    adresse: str
    nom: str
    salle: Optional[List[int]] = None  # 1:N Relationship
    gestionnaire: Optional[List[int]] = None  # 1:N Relationship


class SalleCreate(BaseModel):
    nom: str
    prixBase: int
    capacite: int
    type: str
    tarif_2: int  # N:1 Relationship (mandatory)
    centrecongres_1: int  # N:1 Relationship (mandatory)
    reservation_2: Optional[int] = None  # N:1 Relationship (optional)


class ReservationCreate(BaseModel):
    dateLimiteConfirmation: datetime
    dateFin: date
    dateDebut: date
    estConfirmer: bool
    evenement: Optional[List[int]] = None  # 1:N Relationship
    tarif_1: int  # N:1 Relationship (mandatory)
    ressource: Optional[List[int]] = None  # 1:N Relationship
    salle_1: Optional[List[int]] = None  # 1:N Relationship
    gestionnaire_2: int  # N:1 Relationship (mandatory)


