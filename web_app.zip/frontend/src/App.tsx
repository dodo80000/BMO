import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { TableProvider } from "./contexts/TableContext";
import Reservation from "./pages/Reservation";
import Salle from "./pages/Salle";
import Centrecongres from "./pages/Centrecongres";
import Gestionnaire from "./pages/Gestionnaire";
import Evenement from "./pages/Evenement";
import Ressource from "./pages/Ressource";
import Materiel from "./pages/Materiel";
import Prestation from "./pages/Prestation";
import Tarif from "./pages/Tarif";

function App() {
  return (
    <TableProvider>
      <div className="app-container">
        <main className="app-main">
          <Routes>
            <Route path="/reservation" element={<Reservation />} />
            <Route path="/salle" element={<Salle />} />
            <Route path="/centrecongres" element={<Centrecongres />} />
            <Route path="/gestionnaire" element={<Gestionnaire />} />
            <Route path="/evenement" element={<Evenement />} />
            <Route path="/ressource" element={<Ressource />} />
            <Route path="/materiel" element={<Materiel />} />
            <Route path="/prestation" element={<Prestation />} />
            <Route path="/tarif" element={<Tarif />} />
            <Route path="/" element={<Navigate to="/reservation" replace />} />
            <Route path="*" element={<Navigate to="/reservation" replace />} />
          </Routes>
        </main>
      </div>
    </TableProvider>
  );
}
export default App;
