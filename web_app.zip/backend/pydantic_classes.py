from datetime import datetime, date, time
from typing import Any, List, Optional, Union, Set
from enum import Enum
from pydantic import BaseModel, field_validator

from abc import ABC, abstractmethod

############################################
# Enumerations are defined here
############################################

############################################
# Classes are defined here
############################################
class TarifCreate(BaseModel):
    nomSaison: str
    dateFinSaison: date
    unite: str
    prixUnitaire: int
    dateDebutSaison: date
    ressource_1: Optional[List[int]] = None  # 1:N Relationship
    reservation_4: Optional[List[int]] = None  # 1:N Relationship
    salle_2: Optional[List[int]] = None  # 1:N Relationship


class RessourceCreate(ABC, BaseModel):
    type: str
    prix: int
    stockMax: int
    nom: str
    reservation_1: Optional[int] = None  # N:1 Relationship (optional)
    tarif: int  # N:1 Relationship (mandatory)


class PrestationCreate(RessourceCreate):
    pass


class MaterielCreate(RessourceCreate):
    pass


class EvenementCreate(BaseModel):
    emailreferent: str
    nom: str
    statistique: str
    nbParticipants: int
    description: str
    reservation: int  # N:1 Relationship (mandatory)
    gestionnaire_1: Optional[List[int]] = None  # 1:N Relationship


class GestionnaireCreate(BaseModel):
    attribut: str
    centrecongres: int  # N:1 Relationship (mandatory)
    evenement_1: int  # N:1 Relationship (mandatory)
    reservation_3: Optional[List[int]] = None  # 1:N Relationship


class CentreCongresCreate(BaseModel):
    nom: str
    adresse: str
    gestionnaire: Optional[List[int]] = None  # 1:N Relationship
    salle: Optional[List[int]] = None  # 1:N Relationship


class SalleCreate(BaseModel):
    capacite: int
    nom: str
    prixBase: int
    type: str
    tarif_2: int  # N:1 Relationship (mandatory)
    centrecongres_1: int  # N:1 Relationship (mandatory)
    reservation_2: Optional[int] = None  # N:1 Relationship (optional)


class ReservationCreate(BaseModel):
    dateDebut: date
    dateLimiteConfirmation: datetime
    estConfirmer: bool
    dateFin: date
    ressource: Optional[List[int]] = None  # 1:N Relationship
    evenement: Optional[List[int]] = None  # 1:N Relationship
    salle_1: Optional[List[int]] = None  # 1:N Relationship
    tarif_1: int  # N:1 Relationship (mandatory)
    gestionnaire_2: int  # N:1 Relationship (mandatory)


