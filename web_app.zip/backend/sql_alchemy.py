import enum
from typing import List, Optional
from sqlalchemy import (
    create_engine, Column, ForeignKey, Table, Text, Boolean, String, Date, 
    Time, DateTime, Float, Integer, Enum
)
from sqlalchemy.ext.declarative import AbstractConcreteBase
from sqlalchemy.orm import (
    column_property, DeclarativeBase, Mapped, mapped_column, relationship
)
from datetime import datetime as dt_datetime, time as dt_time, date as dt_date

class Base(DeclarativeBase):
    pass



# Tables definition for many-to-many relationships

# Tables definition
class Tarif(Base):
    __tablename__ = "tarif"
    id: Mapped[int] = mapped_column(primary_key=True)
    nomSaison: Mapped[str] = mapped_column(String(100))
    prixUnitaire: Mapped[int] = mapped_column(Integer)
    unite: Mapped[str] = mapped_column(String(100))
    dateDebutSaison: Mapped[dt_date] = mapped_column(Date)
    dateFinSaison: Mapped[dt_date] = mapped_column(Date)

class Ressource(Base):
    __tablename__ = "ressource"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    type: Mapped[str] = mapped_column(String(100))
    prix: Mapped[int] = mapped_column(Integer)
    stockMax: Mapped[int] = mapped_column(Integer)
    tarif_id: Mapped[int] = mapped_column(ForeignKey("tarif.id"))
    reservation_1_id: Mapped[int] = mapped_column(ForeignKey("reservation.id"), nullable=True)
    type_spec: Mapped[str] = mapped_column(String(50))
    __mapper_args__ = {
        "polymorphic_identity": "ressource",
        "polymorphic_on": "type_spec",
    }

class Prestation(Ressource):
    __tablename__ = "prestation"
    id: Mapped[int] = mapped_column(ForeignKey("ressource.id"), primary_key=True)
    __mapper_args__ = {
        "polymorphic_identity": "prestation",
    }

class Materiel(Ressource):
    __tablename__ = "materiel"
    id: Mapped[int] = mapped_column(ForeignKey("ressource.id"), primary_key=True)
    __mapper_args__ = {
        "polymorphic_identity": "materiel",
    }

class Evenement(Base):
    __tablename__ = "evenement"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(String(100))
    nbParticipants: Mapped[int] = mapped_column(Integer)
    emailreferent: Mapped[str] = mapped_column(String(100))
    statistique: Mapped[str] = mapped_column(String(100))
    reservation_id: Mapped[int] = mapped_column(ForeignKey("reservation.id"))

class Gestionnaire(Base):
    __tablename__ = "gestionnaire"
    id: Mapped[int] = mapped_column(primary_key=True)
    attribut: Mapped[str] = mapped_column(String(100))
    centrecongres_id: Mapped[int] = mapped_column(ForeignKey("centrecongres.id"))
    evenement_1_id: Mapped[int] = mapped_column(ForeignKey("evenement.id"))

class CentreCongres(Base):
    __tablename__ = "centrecongres"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    adresse: Mapped[str] = mapped_column(String(100))

class Salle(Base):
    __tablename__ = "salle"
    id: Mapped[int] = mapped_column(primary_key=True)
    nom: Mapped[str] = mapped_column(String(100))
    type: Mapped[str] = mapped_column(String(100))
    capacite: Mapped[int] = mapped_column(Integer)
    prixBase: Mapped[int] = mapped_column(Integer)
    tarif_2_id: Mapped[int] = mapped_column(ForeignKey("tarif.id"))
    centrecongres_1_id: Mapped[int] = mapped_column(ForeignKey("centrecongres.id"))
    reservation_2_id: Mapped[int] = mapped_column(ForeignKey("reservation.id"), nullable=True)

class Reservation(Base):
    __tablename__ = "reservation"
    id: Mapped[int] = mapped_column(primary_key=True)
    dateDebut: Mapped[dt_date] = mapped_column(Date)
    dateFin: Mapped[dt_date] = mapped_column(Date)
    estConfirmer: Mapped[bool] = mapped_column(Boolean)
    dateLimiteConfirmation: Mapped[dt_datetime] = mapped_column(DateTime)
    tarif_1_id: Mapped[int] = mapped_column(ForeignKey("tarif.id"))
    gestionnaire_2_id: Mapped[int] = mapped_column(ForeignKey("gestionnaire.id"))


#--- Relationships of the tarif table
Tarif.reservation_4: Mapped[List["Reservation"]] = relationship("Reservation", back_populates="tarif_1", foreign_keys=[Reservation.tarif_1_id])
Tarif.ressource_1: Mapped[List["Ressource"]] = relationship("Ressource", back_populates="tarif", foreign_keys=[Ressource.tarif_id])
Tarif.salle_2: Mapped[List["Salle"]] = relationship("Salle", back_populates="tarif_2", foreign_keys=[Salle.tarif_2_id])

#--- Relationships of the ressource table
Ressource.tarif: Mapped["Tarif"] = relationship("Tarif", back_populates="ressource_1", foreign_keys=[Ressource.tarif_id])
Ressource.reservation_1: Mapped["Reservation"] = relationship("Reservation", back_populates="ressource", foreign_keys=[Ressource.reservation_1_id])

#--- Relationships of the evenement table
Evenement.gestionnaire_1: Mapped[List["Gestionnaire"]] = relationship("Gestionnaire", back_populates="evenement_1", foreign_keys=[Gestionnaire.evenement_1_id])
Evenement.reservation: Mapped["Reservation"] = relationship("Reservation", back_populates="evenement", foreign_keys=[Evenement.reservation_id])

#--- Relationships of the gestionnaire table
Gestionnaire.reservation_3: Mapped[List["Reservation"]] = relationship("Reservation", back_populates="gestionnaire_2", foreign_keys=[Reservation.gestionnaire_2_id])
Gestionnaire.centrecongres: Mapped["CentreCongres"] = relationship("CentreCongres", back_populates="gestionnaire", foreign_keys=[Gestionnaire.centrecongres_id])
Gestionnaire.evenement_1: Mapped["Evenement"] = relationship("Evenement", back_populates="gestionnaire_1", foreign_keys=[Gestionnaire.evenement_1_id])

#--- Relationships of the centrecongres table
CentreCongres.salle: Mapped[List["Salle"]] = relationship("Salle", back_populates="centrecongres_1", foreign_keys=[Salle.centrecongres_1_id])
CentreCongres.gestionnaire: Mapped[List["Gestionnaire"]] = relationship("Gestionnaire", back_populates="centrecongres", foreign_keys=[Gestionnaire.centrecongres_id])

#--- Relationships of the salle table
Salle.tarif_2: Mapped["Tarif"] = relationship("Tarif", back_populates="salle_2", foreign_keys=[Salle.tarif_2_id])
Salle.centrecongres_1: Mapped["CentreCongres"] = relationship("CentreCongres", back_populates="salle", foreign_keys=[Salle.centrecongres_1_id])
Salle.reservation_2: Mapped["Reservation"] = relationship("Reservation", back_populates="salle_1", foreign_keys=[Salle.reservation_2_id])

#--- Relationships of the reservation table
Reservation.evenement: Mapped[List["Evenement"]] = relationship("Evenement", back_populates="reservation", foreign_keys=[Evenement.reservation_id])
Reservation.salle_1: Mapped[List["Salle"]] = relationship("Salle", back_populates="reservation_2", foreign_keys=[Salle.reservation_2_id])
Reservation.tarif_1: Mapped["Tarif"] = relationship("Tarif", back_populates="reservation_4", foreign_keys=[Reservation.tarif_1_id])
Reservation.ressource: Mapped[List["Ressource"]] = relationship("Ressource", back_populates="reservation_1", foreign_keys=[Ressource.reservation_1_id])
Reservation.gestionnaire_2: Mapped["Gestionnaire"] = relationship("Gestionnaire", back_populates="reservation_3", foreign_keys=[Reservation.gestionnaire_2_id])

# Database connection
DATABASE_URL = "sqlite:///Class_Diagram.db"  # SQLite connection
engine = create_engine(DATABASE_URL, echo=True)

# Create tables in the database
Base.metadata.create_all(engine, checkfirst=True)