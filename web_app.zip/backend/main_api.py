import uvicorn
import os, json
import time as time_module
import logging
from fastapi import Depends, FastAPI, HTTPException, Request, status, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from pydantic_classes import *
from sql_alchemy import *

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

############################################
#
#   Initialize the database
#
############################################

def init_db():
    SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/Class_Diagram.db")
    # Ensure local SQLite directory exists (safe no-op for other DBs)
    os.makedirs("data", exist_ok=True)
    engine = create_engine(
        SQLALCHEMY_DATABASE_URL,
        connect_args={"check_same_thread": False},
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        echo=False
    )
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    return SessionLocal

app = FastAPI(
    title="Class_Diagram API",
    description="Auto-generated REST API with full CRUD operations, relationship management, and advanced features",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {"name": "System", "description": "System health and statistics"},
        {"name": "Tarif", "description": "Operations for Tarif entities"},
        {"name": "Tarif Relationships", "description": "Manage Tarif relationships"},
        {"name": "Tarif Methods", "description": "Execute Tarif methods"},
        {"name": "Ressource", "description": "Operations for Ressource entities"},
        {"name": "Ressource Relationships", "description": "Manage Ressource relationships"},
        {"name": "Ressource Methods", "description": "Execute Ressource methods"},
        {"name": "Prestation", "description": "Operations for Prestation entities"},
        {"name": "Prestation Methods", "description": "Execute Prestation methods"},
        {"name": "Materiel", "description": "Operations for Materiel entities"},
        {"name": "Materiel Methods", "description": "Execute Materiel methods"},
        {"name": "Evenement", "description": "Operations for Evenement entities"},
        {"name": "Evenement Relationships", "description": "Manage Evenement relationships"},
        {"name": "Evenement Methods", "description": "Execute Evenement methods"},
        {"name": "Gestionnaire", "description": "Operations for Gestionnaire entities"},
        {"name": "Gestionnaire Relationships", "description": "Manage Gestionnaire relationships"},
        {"name": "Gestionnaire Methods", "description": "Execute Gestionnaire methods"},
        {"name": "CentreCongres", "description": "Operations for CentreCongres entities"},
        {"name": "CentreCongres Relationships", "description": "Manage CentreCongres relationships"},
        {"name": "CentreCongres Methods", "description": "Execute CentreCongres methods"},
        {"name": "Salle", "description": "Operations for Salle entities"},
        {"name": "Salle Relationships", "description": "Manage Salle relationships"},
        {"name": "Salle Methods", "description": "Execute Salle methods"},
        {"name": "Reservation", "description": "Operations for Reservation entities"},
        {"name": "Reservation Relationships", "description": "Manage Reservation relationships"},
        {"name": "Reservation Methods", "description": "Execute Reservation methods"},
    ]
)

# Enable CORS for all origins (for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or restrict to ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

############################################
#
#   Middleware
#
############################################

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all incoming requests and responses."""
    logger.info(f"Incoming request: {request.method} {request.url.path}")
    response = await call_next(request)
    logger.info(f"Response status: {response.status_code}")
    return response

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add processing time header to all responses."""
    start_time = time_module.time()
    response = await call_next(request)
    process_time = time_module.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

############################################
#
#   Exception Handlers
#
############################################

# Global exception handlers
@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    """Handle ValueError exceptions."""
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={
            "error": "Bad Request",
            "message": str(exc),
            "detail": "Invalid input data provided"
        }
    )


@app.exception_handler(IntegrityError)
async def integrity_error_handler(request: Request, exc: IntegrityError):
    """Handle database integrity errors."""
    logger.error(f"Database integrity error: {exc}")

    # Extract more detailed error information
    error_detail = str(exc.orig) if hasattr(exc, 'orig') else str(exc)

    return JSONResponse(
        status_code=status.HTTP_409_CONFLICT,
        content={
            "error": "Conflict",
            "message": "Data conflict occurred",
            "detail": error_detail
        }
    )


@app.exception_handler(SQLAlchemyError)
async def sqlalchemy_error_handler(request: Request, exc: SQLAlchemyError):
    """Handle general SQLAlchemy errors."""
    logger.error(f"Database error: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal Server Error",
            "message": "Database operation failed",
            "detail": "An internal database error occurred"
        }
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions with consistent format."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail if isinstance(exc.detail, str) else "HTTP Error",
            "message": exc.detail,
            "detail": f"HTTP {exc.status_code} error occurred"
        }
    )

# Initialize database session
SessionLocal = init_db()
# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        logger.error("Database session rollback due to exception")
        raise
    finally:
        db.close()

############################################
#
#   Global API endpoints
#
############################################

@app.get("/", tags=["System"])
def root():
    """Root endpoint - API information"""
    return {
        "name": "Class_Diagram API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health", tags=["System"])
def health_check():
    """Health check endpoint for monitoring"""
    from datetime import datetime
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "database": "connected"
    }


@app.get("/statistics", tags=["System"])
def get_statistics(database: Session = Depends(get_db)):
    """Get database statistics for all entities"""
    stats = {}
    stats["tarif_count"] = database.query(Tarif).count()
    stats["ressource_count"] = database.query(Ressource).count()
    stats["prestation_count"] = database.query(Prestation).count()
    stats["materiel_count"] = database.query(Materiel).count()
    stats["evenement_count"] = database.query(Evenement).count()
    stats["gestionnaire_count"] = database.query(Gestionnaire).count()
    stats["centrecongres_count"] = database.query(CentreCongres).count()
    stats["salle_count"] = database.query(Salle).count()
    stats["reservation_count"] = database.query(Reservation).count()
    stats["total_entities"] = sum(stats.values())
    return stats


############################################
#
#   BESSER Action Language standard lib
#
############################################


async def BAL_size(sequence:list) -> int:
    return len(sequence)

async def BAL_is_empty(sequence:list) -> bool:
    return len(sequence) == 0

async def BAL_add(sequence:list, elem) -> None:
    sequence.append(elem)

async def BAL_remove(sequence:list, elem) -> None:
    sequence.remove(elem)

async def BAL_contains(sequence:list, elem) -> bool:
    return elem in sequence

async def BAL_filter(sequence:list, predicate) -> list:
    return [elem for elem in sequence if predicate(elem)]

async def BAL_forall(sequence:list, predicate) -> bool:
    for elem in sequence:
        if not predicate(elem):
            return False
    return True

async def BAL_exists(sequence:list, predicate) -> bool:
    for elem in sequence:
        if predicate(elem):
            return True
    return False

async def BAL_one(sequence:list, predicate) -> bool:
    found = False
    for elem in sequence:
        if predicate(elem):
            if found:
                return False
            found = True
    return found

async def BAL_is_unique(sequence:list, mapping) -> bool:
    mapped = [mapping(elem) for elem in sequence]
    return len(set(mapped)) == len(mapped)

async def BAL_map(sequence:list, mapping) -> list:
    return [mapping(elem) for elem in sequence]

async def BAL_reduce(sequence:list, reduce_fn, aggregator) -> any:
    for elem in sequence:
        aggregator = reduce_fn(aggregator, elem)
    return aggregator


############################################
#
#   Tarif functions
#
############################################

@app.get("/tarif/", response_model=None, tags=["Tarif"])
def get_all_tarif(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Tarif)
        tarif_list = query.all()

        # Serialize with relationships included
        result = []
        for tarif_item in tarif_list:
            item_dict = tarif_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)

            # Add many-to-many and one-to-many relationship objects (full details)
            ressource_list = database.query(Ressource).filter(Ressource.tarif_id == tarif_item.id).all()
            item_dict['ressource_1'] = []
            for ressource_obj in ressource_list:
                ressource_dict = ressource_obj.__dict__.copy()
                ressource_dict.pop('_sa_instance_state', None)
                item_dict['ressource_1'].append(ressource_dict)
            reservation_list = database.query(Reservation).filter(Reservation.tarif_1_id == tarif_item.id).all()
            item_dict['reservation_4'] = []
            for reservation_obj in reservation_list:
                reservation_dict = reservation_obj.__dict__.copy()
                reservation_dict.pop('_sa_instance_state', None)
                item_dict['reservation_4'].append(reservation_dict)
            salle_list = database.query(Salle).filter(Salle.tarif_2_id == tarif_item.id).all()
            item_dict['salle_2'] = []
            for salle_obj in salle_list:
                salle_dict = salle_obj.__dict__.copy()
                salle_dict.pop('_sa_instance_state', None)
                item_dict['salle_2'].append(salle_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Tarif).all()


@app.get("/tarif/count/", response_model=None, tags=["Tarif"])
def get_count_tarif(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Tarif entities"""
    count = database.query(Tarif).count()
    return {"count": count}


@app.get("/tarif/paginated/", response_model=None, tags=["Tarif"])
def get_paginated_tarif(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Tarif entities"""
    total = database.query(Tarif).count()
    tarif_list = database.query(Tarif).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": tarif_list
        }

    result = []
    for tarif_item in tarif_list:
        ressource_1_ids = database.query(Ressource.id).filter(Ressource.tarif_id == tarif_item.id).all()
        reservation_4_ids = database.query(Reservation.id).filter(Reservation.tarif_1_id == tarif_item.id).all()
        salle_2_ids = database.query(Salle.id).filter(Salle.tarif_2_id == tarif_item.id).all()
        item_data = {
            "tarif": tarif_item,
            "ressource_1_ids": [x[0] for x in ressource_1_ids],            "reservation_4_ids": [x[0] for x in reservation_4_ids],            "salle_2_ids": [x[0] for x in salle_2_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/tarif/search/", response_model=None, tags=["Tarif"])
def search_tarif(
    database: Session = Depends(get_db)
) -> list:
    """Search Tarif entities by attributes"""
    query = database.query(Tarif)


    results = query.all()
    return results


@app.get("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def get_tarif(tarif_id: int, database: Session = Depends(get_db)) -> Tarif:
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")

    ressource_1_ids = database.query(Ressource.id).filter(Ressource.tarif_id == db_tarif.id).all()
    reservation_4_ids = database.query(Reservation.id).filter(Reservation.tarif_1_id == db_tarif.id).all()
    salle_2_ids = database.query(Salle.id).filter(Salle.tarif_2_id == db_tarif.id).all()
    response_data = {
        "tarif": db_tarif,
        "ressource_1_ids": [x[0] for x in ressource_1_ids],        "reservation_4_ids": [x[0] for x in reservation_4_ids],        "salle_2_ids": [x[0] for x in salle_2_ids]}
    return response_data



@app.post("/tarif/", response_model=None, tags=["Tarif"])
async def create_tarif(tarif_data: TarifCreate, database: Session = Depends(get_db)) -> Tarif:


    db_tarif = Tarif(
        nomSaison=tarif_data.nomSaison,        dateFinSaison=tarif_data.dateFinSaison,        unite=tarif_data.unite,        prixUnitaire=tarif_data.prixUnitaire,        dateDebutSaison=tarif_data.dateDebutSaison        )

    database.add(db_tarif)
    database.commit()
    database.refresh(db_tarif)

    if tarif_data.ressource_1:
        # Validate that all Ressource IDs exist
        for ressource_id in tarif_data.ressource_1:
            db_ressource = database.query(Ressource).filter(Ressource.id == ressource_id).first()
            if not db_ressource:
                raise HTTPException(status_code=400, detail=f"Ressource with id {ressource_id} not found")

        # Update the related entities with the new foreign key
        database.query(Ressource).filter(Ressource.id.in_(tarif_data.ressource_1)).update(
            {Ressource.tarif_id: db_tarif.id}, synchronize_session=False
        )
        database.commit()
    if tarif_data.reservation_4:
        # Validate that all Reservation IDs exist
        for reservation_id in tarif_data.reservation_4:
            db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
            if not db_reservation:
                raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

        # Update the related entities with the new foreign key
        database.query(Reservation).filter(Reservation.id.in_(tarif_data.reservation_4)).update(
            {Reservation.tarif_1_id: db_tarif.id}, synchronize_session=False
        )
        database.commit()
    if tarif_data.salle_2:
        # Validate that all Salle IDs exist
        for salle_id in tarif_data.salle_2:
            db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
            if not db_salle:
                raise HTTPException(status_code=400, detail=f"Salle with id {salle_id} not found")

        # Update the related entities with the new foreign key
        database.query(Salle).filter(Salle.id.in_(tarif_data.salle_2)).update(
            {Salle.tarif_2_id: db_tarif.id}, synchronize_session=False
        )
        database.commit()



    ressource_1_ids = database.query(Ressource.id).filter(Ressource.tarif_id == db_tarif.id).all()
    reservation_4_ids = database.query(Reservation.id).filter(Reservation.tarif_1_id == db_tarif.id).all()
    salle_2_ids = database.query(Salle.id).filter(Salle.tarif_2_id == db_tarif.id).all()
    response_data = {
        "tarif": db_tarif,
        "ressource_1_ids": [x[0] for x in ressource_1_ids],        "reservation_4_ids": [x[0] for x in reservation_4_ids],        "salle_2_ids": [x[0] for x in salle_2_ids]    }
    return response_data


@app.post("/tarif/bulk/", response_model=None, tags=["Tarif"])
async def bulk_create_tarif(items: list[TarifCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Tarif entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_tarif = Tarif(
                nomSaison=item_data.nomSaison,                dateFinSaison=item_data.dateFinSaison,                unite=item_data.unite,                prixUnitaire=item_data.prixUnitaire,                dateDebutSaison=item_data.dateDebutSaison            )
            database.add(db_tarif)
            database.flush()  # Get ID without committing
            created_items.append(db_tarif.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Tarif entities"
    }


@app.delete("/tarif/bulk/", response_model=None, tags=["Tarif"])
async def bulk_delete_tarif(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Tarif entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_tarif = database.query(Tarif).filter(Tarif.id == item_id).first()
        if db_tarif:
            database.delete(db_tarif)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Tarif entities"
    }

@app.put("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def update_tarif(tarif_id: int, tarif_data: TarifCreate, database: Session = Depends(get_db)) -> Tarif:
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")

    setattr(db_tarif, 'nomSaison', tarif_data.nomSaison)
    setattr(db_tarif, 'dateFinSaison', tarif_data.dateFinSaison)
    setattr(db_tarif, 'unite', tarif_data.unite)
    setattr(db_tarif, 'prixUnitaire', tarif_data.prixUnitaire)
    setattr(db_tarif, 'dateDebutSaison', tarif_data.dateDebutSaison)
    if tarif_data.ressource_1 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Ressource).filter(Ressource.tarif_id == db_tarif.id).update(
            {Ressource.tarif_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if tarif_data.ressource_1:
            # Validate that all IDs exist
            for ressource_id in tarif_data.ressource_1:
                db_ressource = database.query(Ressource).filter(Ressource.id == ressource_id).first()
                if not db_ressource:
                    raise HTTPException(status_code=400, detail=f"Ressource with id {ressource_id} not found")

            # Update the related entities with the new foreign key
            database.query(Ressource).filter(Ressource.id.in_(tarif_data.ressource_1)).update(
                {Ressource.tarif_id: db_tarif.id}, synchronize_session=False
            )
    if tarif_data.reservation_4 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Reservation).filter(Reservation.tarif_1_id == db_tarif.id).update(
            {Reservation.tarif_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if tarif_data.reservation_4:
            # Validate that all IDs exist
            for reservation_id in tarif_data.reservation_4:
                db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
                if not db_reservation:
                    raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

            # Update the related entities with the new foreign key
            database.query(Reservation).filter(Reservation.id.in_(tarif_data.reservation_4)).update(
                {Reservation.tarif_1_id: db_tarif.id}, synchronize_session=False
            )
    if tarif_data.salle_2 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Salle).filter(Salle.tarif_2_id == db_tarif.id).update(
            {Salle.tarif_2_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if tarif_data.salle_2:
            # Validate that all IDs exist
            for salle_id in tarif_data.salle_2:
                db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
                if not db_salle:
                    raise HTTPException(status_code=400, detail=f"Salle with id {salle_id} not found")

            # Update the related entities with the new foreign key
            database.query(Salle).filter(Salle.id.in_(tarif_data.salle_2)).update(
                {Salle.tarif_2_id: db_tarif.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_tarif)

    ressource_1_ids = database.query(Ressource.id).filter(Ressource.tarif_id == db_tarif.id).all()
    reservation_4_ids = database.query(Reservation.id).filter(Reservation.tarif_1_id == db_tarif.id).all()
    salle_2_ids = database.query(Salle.id).filter(Salle.tarif_2_id == db_tarif.id).all()
    response_data = {
        "tarif": db_tarif,
        "ressource_1_ids": [x[0] for x in ressource_1_ids],        "reservation_4_ids": [x[0] for x in reservation_4_ids],        "salle_2_ids": [x[0] for x in salle_2_ids]    }
    return response_data


@app.delete("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def delete_tarif(tarif_id: int, database: Session = Depends(get_db)):
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")
    database.delete(db_tarif)
    database.commit()
    return db_tarif



############################################
#   Tarif Method Endpoints
############################################




@app.post("/tarif/methods/estApplicable/", response_model=None, tags=["Tarif Methods"])
async def tarif_estApplicable(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the estApplicable class method on Tarif.
    This method operates on all Tarif entities or performs class-level operations.

    Parameters (pass as JSON body):
    - date: Any    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        date = params.get('date')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Tarif",
            "method": "estApplicable",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/tarif/methods/calculerPrix/", response_model=None, tags=["Tarif Methods"])
async def tarif_calculerPrix(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the calculerPrix class method on Tarif.
    This method operates on all Tarif entities or performs class-level operations.

    Parameters (pass as JSON body):
    - duree: Any    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        duree = params.get('duree')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Tarif",
            "method": "calculerPrix",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/tarif/methods/Tarif/", response_model=None, tags=["Tarif Methods"])
async def tarif_Tarif(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the Tarif class method on Tarif.
    This method operates on all Tarif entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nomSaison: str    - prixUnitaire: float    - unite: str    - dateDebutSaison: date    - dateFinSaison: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nomSaison = params.get('nomSaison')
        prixUnitaire = params.get('prixUnitaire')
        unite = params.get('unite')
        dateDebutSaison = params.get('dateDebutSaison')
        dateFinSaison = params.get('dateFinSaison')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Tarif",
            "method": "Tarif",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Ressource functions
#
############################################

@app.get("/ressource/", response_model=None, tags=["Ressource"])
def get_all_ressource(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Ressource)
        query = query.options(joinedload(Ressource.reservation_1))
        query = query.options(joinedload(Ressource.tarif))
        ressource_list = query.all()

        # Serialize with relationships included
        result = []
        for ressource_item in ressource_list:
            item_dict = ressource_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if ressource_item.reservation_1:
                related_obj = ressource_item.reservation_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation_1'] = related_dict
            else:
                item_dict['reservation_1'] = None
            if ressource_item.tarif:
                related_obj = ressource_item.tarif
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['tarif'] = related_dict
            else:
                item_dict['tarif'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Ressource).all()


@app.get("/ressource/count/", response_model=None, tags=["Ressource"])
def get_count_ressource(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Ressource entities"""
    count = database.query(Ressource).count()
    return {"count": count}


@app.get("/ressource/paginated/", response_model=None, tags=["Ressource"])
def get_paginated_ressource(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Ressource entities"""
    total = database.query(Ressource).count()
    ressource_list = database.query(Ressource).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": ressource_list
    }


@app.get("/ressource/search/", response_model=None, tags=["Ressource"])
def search_ressource(
    database: Session = Depends(get_db)
) -> list:
    """Search Ressource entities by attributes"""
    query = database.query(Ressource)


    results = query.all()
    return results


@app.get("/ressource/{ressource_id}/", response_model=None, tags=["Ressource"])
async def get_ressource(ressource_id: int, database: Session = Depends(get_db)) -> Ressource:
    db_ressource = database.query(Ressource).filter(Ressource.id == ressource_id).first()
    if db_ressource is None:
        raise HTTPException(status_code=404, detail="Ressource not found")

    response_data = {
        "ressource": db_ressource,
}
    return response_data



@app.post("/ressource/", response_model=None, tags=["Ressource"])
async def create_ressource(ressource_data: RessourceCreate, database: Session = Depends(get_db)) -> Ressource:

    if ressource_data.reservation_1 :
        db_reservation_1 = database.query(Reservation).filter(Reservation.id == ressource_data.reservation_1).first()
        if not db_reservation_1:
            raise HTTPException(status_code=400, detail="Reservation not found")
    if ressource_data.tarif is not None:
        db_tarif = database.query(Tarif).filter(Tarif.id == ressource_data.tarif).first()
        if not db_tarif:
            raise HTTPException(status_code=400, detail="Tarif not found")
    else:
        raise HTTPException(status_code=400, detail="Tarif ID is required")

    db_ressource = Ressource(
        type=ressource_data.type,        prix=ressource_data.prix,        stockMax=ressource_data.stockMax,        nom=ressource_data.nom,        reservation_1_id=ressource_data.reservation_1,        tarif_id=ressource_data.tarif        )

    database.add(db_ressource)
    database.commit()
    database.refresh(db_ressource)




    return db_ressource


@app.post("/ressource/bulk/", response_model=None, tags=["Ressource"])
async def bulk_create_ressource(items: list[RessourceCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Ressource entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.tarif:
                raise ValueError("Tarif ID is required")

            db_ressource = Ressource(
                type=item_data.type,                prix=item_data.prix,                stockMax=item_data.stockMax,                nom=item_data.nom,                reservation_1_id=item_data.reservation_1,                tarif_id=item_data.tarif            )
            database.add(db_ressource)
            database.flush()  # Get ID without committing
            created_items.append(db_ressource.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Ressource entities"
    }


@app.delete("/ressource/bulk/", response_model=None, tags=["Ressource"])
async def bulk_delete_ressource(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Ressource entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_ressource = database.query(Ressource).filter(Ressource.id == item_id).first()
        if db_ressource:
            database.delete(db_ressource)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Ressource entities"
    }

@app.put("/ressource/{ressource_id}/", response_model=None, tags=["Ressource"])
async def update_ressource(ressource_id: int, ressource_data: RessourceCreate, database: Session = Depends(get_db)) -> Ressource:
    db_ressource = database.query(Ressource).filter(Ressource.id == ressource_id).first()
    if db_ressource is None:
        raise HTTPException(status_code=404, detail="Ressource not found")

    setattr(db_ressource, 'type', ressource_data.type)
    setattr(db_ressource, 'prix', ressource_data.prix)
    setattr(db_ressource, 'stockMax', ressource_data.stockMax)
    setattr(db_ressource, 'nom', ressource_data.nom)
    if ressource_data.reservation_1 is not None:
        db_reservation_1 = database.query(Reservation).filter(Reservation.id == ressource_data.reservation_1).first()
        if not db_reservation_1:
            raise HTTPException(status_code=400, detail="Reservation not found")
        setattr(db_ressource, 'reservation_1_id', ressource_data.reservation_1)
    else:
        setattr(db_ressource, 'reservation_1_id', None)
    if ressource_data.tarif is not None:
        db_tarif = database.query(Tarif).filter(Tarif.id == ressource_data.tarif).first()
        if not db_tarif:
            raise HTTPException(status_code=400, detail="Tarif not found")
        setattr(db_ressource, 'tarif_id', ressource_data.tarif)
    database.commit()
    database.refresh(db_ressource)

    return db_ressource


@app.delete("/ressource/{ressource_id}/", response_model=None, tags=["Ressource"])
async def delete_ressource(ressource_id: int, database: Session = Depends(get_db)):
    db_ressource = database.query(Ressource).filter(Ressource.id == ressource_id).first()
    if db_ressource is None:
        raise HTTPException(status_code=404, detail="Ressource not found")
    database.delete(db_ressource)
    database.commit()
    return db_ressource



############################################
#   Ressource Method Endpoints
############################################




@app.post("/ressource/methods/calculerCout/", response_model=None, tags=["Ressource Methods"])
async def ressource_calculerCout(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the calculerCout class method on Ressource.
    This method operates on all Ressource entities or performs class-level operations.

    Parameters (pass as JSON body):
    - quantite: Any    - duree: Any    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        quantite = params.get('quantite')
        duree = params.get('duree')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Ressource",
            "method": "calculerCout",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/ressource/methods/verifierStock/", response_model=None, tags=["Ressource Methods"])
async def ressource_verifierStock(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the verifierStock class method on Ressource.
    This method operates on all Ressource entities or performs class-level operations.

    Parameters (pass as JSON body):
    - quantite: Any    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        quantite = params.get('quantite')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Ressource",
            "method": "verifierStock",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/ressource/methods/Ressource/", response_model=None, tags=["Ressource Methods"])
async def ressource_Ressource(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the Ressource class method on Ressource.
    This method operates on all Ressource entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nomR: str    - typeR: str    - prixR: float    - stockMaxR: int    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nomR = params.get('nomR')
        typeR = params.get('typeR')
        prixR = params.get('prixR')
        stockMaxR = params.get('stockMaxR')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Ressource",
            "method": "Ressource",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/ressource/methods/estDisponible/", response_model=None, tags=["Ressource Methods"])
async def ressource_estDisponible(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the estDisponible class method on Ressource.
    This method operates on all Ressource entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebutParam: date    - dateFinParam: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebutParam = params.get('dateDebutParam')
        dateFinParam = params.get('dateFinParam')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Ressource",
            "method": "estDisponible",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Prestation functions
#
############################################

@app.get("/prestation/", response_model=None, tags=["Prestation"])
def get_all_prestation(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Prestation)
        query = query.options(joinedload(Prestation.reservation_1))
        query = query.options(joinedload(Prestation.tarif))
        prestation_list = query.all()

        # Serialize with relationships included
        result = []
        for prestation_item in prestation_list:
            item_dict = prestation_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if prestation_item.reservation_1:
                related_obj = prestation_item.reservation_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation_1'] = related_dict
            else:
                item_dict['reservation_1'] = None
            if prestation_item.tarif:
                related_obj = prestation_item.tarif
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['tarif'] = related_dict
            else:
                item_dict['tarif'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Prestation).all()


@app.get("/prestation/count/", response_model=None, tags=["Prestation"])
def get_count_prestation(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Prestation entities"""
    count = database.query(Prestation).count()
    return {"count": count}


@app.get("/prestation/paginated/", response_model=None, tags=["Prestation"])
def get_paginated_prestation(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Prestation entities"""
    total = database.query(Prestation).count()
    prestation_list = database.query(Prestation).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": prestation_list
    }


@app.get("/prestation/search/", response_model=None, tags=["Prestation"])
def search_prestation(
    database: Session = Depends(get_db)
) -> list:
    """Search Prestation entities by attributes"""
    query = database.query(Prestation)


    results = query.all()
    return results


@app.get("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def get_prestation(prestation_id: int, database: Session = Depends(get_db)) -> Prestation:
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    response_data = {
        "prestation": db_prestation,
}
    return response_data



@app.post("/prestation/", response_model=None, tags=["Prestation"])
async def create_prestation(prestation_data: PrestationCreate, database: Session = Depends(get_db)) -> Prestation:

    if prestation_data.reservation_1 :
        db_reservation_1 = database.query(Reservation).filter(Reservation.id == prestation_data.reservation_1).first()
        if not db_reservation_1:
            raise HTTPException(status_code=400, detail="Reservation not found")
    if prestation_data.tarif is not None:
        db_tarif = database.query(Tarif).filter(Tarif.id == prestation_data.tarif).first()
        if not db_tarif:
            raise HTTPException(status_code=400, detail="Tarif not found")
    else:
        raise HTTPException(status_code=400, detail="Tarif ID is required")

    db_prestation = Prestation(
        type=prestation_data.type,        prix=prestation_data.prix,        stockMax=prestation_data.stockMax,        nom=prestation_data.nom,        reservation_1_id=prestation_data.reservation_1,        tarif_id=prestation_data.tarif        )

    database.add(db_prestation)
    database.commit()
    database.refresh(db_prestation)




    return db_prestation


@app.post("/prestation/bulk/", response_model=None, tags=["Prestation"])
async def bulk_create_prestation(items: list[PrestationCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Prestation entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.tarif:
                raise ValueError("Tarif ID is required")

            db_prestation = Prestation(
                type=item_data.type,                prix=item_data.prix,                stockMax=item_data.stockMax,                nom=item_data.nom,                reservation_1_id=item_data.reservation_1,                tarif_id=item_data.tarif            )
            database.add(db_prestation)
            database.flush()  # Get ID without committing
            created_items.append(db_prestation.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Prestation entities"
    }


@app.delete("/prestation/bulk/", response_model=None, tags=["Prestation"])
async def bulk_delete_prestation(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Prestation entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_prestation = database.query(Prestation).filter(Prestation.id == item_id).first()
        if db_prestation:
            database.delete(db_prestation)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Prestation entities"
    }

@app.put("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def update_prestation(prestation_id: int, prestation_data: PrestationCreate, database: Session = Depends(get_db)) -> Prestation:
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    database.commit()
    database.refresh(db_prestation)

    return db_prestation


@app.delete("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def delete_prestation(prestation_id: int, database: Session = Depends(get_db)):
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")
    database.delete(db_prestation)
    database.commit()
    return db_prestation



############################################
#   Prestation Method Endpoints
############################################




@app.post("/prestation/methods/Prestation/", response_model=None, tags=["Prestation Methods"])
async def prestation_Prestation(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the Prestation class method on Prestation.
    This method operates on all Prestation entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nomR: str    - typeR: str    - prixR: float    - stockMaxR: int    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nomR = params.get('nomR')
        typeR = params.get('typeR')
        prixR = params.get('prixR')
        stockMaxR = params.get('stockMaxR')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Prestation",
            "method": "Prestation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Materiel functions
#
############################################

@app.get("/materiel/", response_model=None, tags=["Materiel"])
def get_all_materiel(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Materiel)
        query = query.options(joinedload(Materiel.reservation_1))
        query = query.options(joinedload(Materiel.tarif))
        materiel_list = query.all()

        # Serialize with relationships included
        result = []
        for materiel_item in materiel_list:
            item_dict = materiel_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if materiel_item.reservation_1:
                related_obj = materiel_item.reservation_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation_1'] = related_dict
            else:
                item_dict['reservation_1'] = None
            if materiel_item.tarif:
                related_obj = materiel_item.tarif
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['tarif'] = related_dict
            else:
                item_dict['tarif'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Materiel).all()


@app.get("/materiel/count/", response_model=None, tags=["Materiel"])
def get_count_materiel(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Materiel entities"""
    count = database.query(Materiel).count()
    return {"count": count}


@app.get("/materiel/paginated/", response_model=None, tags=["Materiel"])
def get_paginated_materiel(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Materiel entities"""
    total = database.query(Materiel).count()
    materiel_list = database.query(Materiel).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": materiel_list
    }


@app.get("/materiel/search/", response_model=None, tags=["Materiel"])
def search_materiel(
    database: Session = Depends(get_db)
) -> list:
    """Search Materiel entities by attributes"""
    query = database.query(Materiel)


    results = query.all()
    return results


@app.get("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def get_materiel(materiel_id: int, database: Session = Depends(get_db)) -> Materiel:
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    response_data = {
        "materiel": db_materiel,
}
    return response_data



@app.post("/materiel/", response_model=None, tags=["Materiel"])
async def create_materiel(materiel_data: MaterielCreate, database: Session = Depends(get_db)) -> Materiel:

    if materiel_data.reservation_1 :
        db_reservation_1 = database.query(Reservation).filter(Reservation.id == materiel_data.reservation_1).first()
        if not db_reservation_1:
            raise HTTPException(status_code=400, detail="Reservation not found")
    if materiel_data.tarif is not None:
        db_tarif = database.query(Tarif).filter(Tarif.id == materiel_data.tarif).first()
        if not db_tarif:
            raise HTTPException(status_code=400, detail="Tarif not found")
    else:
        raise HTTPException(status_code=400, detail="Tarif ID is required")

    db_materiel = Materiel(
        type=materiel_data.type,        prix=materiel_data.prix,        stockMax=materiel_data.stockMax,        nom=materiel_data.nom,        reservation_1_id=materiel_data.reservation_1,        tarif_id=materiel_data.tarif        )

    database.add(db_materiel)
    database.commit()
    database.refresh(db_materiel)




    return db_materiel


@app.post("/materiel/bulk/", response_model=None, tags=["Materiel"])
async def bulk_create_materiel(items: list[MaterielCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Materiel entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.tarif:
                raise ValueError("Tarif ID is required")

            db_materiel = Materiel(
                type=item_data.type,                prix=item_data.prix,                stockMax=item_data.stockMax,                nom=item_data.nom,                reservation_1_id=item_data.reservation_1,                tarif_id=item_data.tarif            )
            database.add(db_materiel)
            database.flush()  # Get ID without committing
            created_items.append(db_materiel.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Materiel entities"
    }


@app.delete("/materiel/bulk/", response_model=None, tags=["Materiel"])
async def bulk_delete_materiel(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Materiel entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_materiel = database.query(Materiel).filter(Materiel.id == item_id).first()
        if db_materiel:
            database.delete(db_materiel)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Materiel entities"
    }

@app.put("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def update_materiel(materiel_id: int, materiel_data: MaterielCreate, database: Session = Depends(get_db)) -> Materiel:
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    database.commit()
    database.refresh(db_materiel)

    return db_materiel


@app.delete("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def delete_materiel(materiel_id: int, database: Session = Depends(get_db)):
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")
    database.delete(db_materiel)
    database.commit()
    return db_materiel



############################################
#   Materiel Method Endpoints
############################################




@app.post("/materiel/methods/Materiel/", response_model=None, tags=["Materiel Methods"])
async def materiel_Materiel(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the Materiel class method on Materiel.
    This method operates on all Materiel entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nomR: str    - typeR: str    - prixR: float    - stockMaxR: int    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nomR = params.get('nomR')
        typeR = params.get('typeR')
        prixR = params.get('prixR')
        stockMaxR = params.get('stockMaxR')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Materiel",
            "method": "Materiel",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Evenement functions
#
############################################

@app.get("/evenement/", response_model=None, tags=["Evenement"])
def get_all_evenement(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Evenement)
        query = query.options(joinedload(Evenement.reservation))
        evenement_list = query.all()

        # Serialize with relationships included
        result = []
        for evenement_item in evenement_list:
            item_dict = evenement_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if evenement_item.reservation:
                related_obj = evenement_item.reservation
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation'] = related_dict
            else:
                item_dict['reservation'] = None

            # Add many-to-many and one-to-many relationship objects (full details)
            gestionnaire_list = database.query(Gestionnaire).filter(Gestionnaire.evenement_1_id == evenement_item.id).all()
            item_dict['gestionnaire_1'] = []
            for gestionnaire_obj in gestionnaire_list:
                gestionnaire_dict = gestionnaire_obj.__dict__.copy()
                gestionnaire_dict.pop('_sa_instance_state', None)
                item_dict['gestionnaire_1'].append(gestionnaire_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Evenement).all()


@app.get("/evenement/count/", response_model=None, tags=["Evenement"])
def get_count_evenement(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Evenement entities"""
    count = database.query(Evenement).count()
    return {"count": count}


@app.get("/evenement/paginated/", response_model=None, tags=["Evenement"])
def get_paginated_evenement(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Evenement entities"""
    total = database.query(Evenement).count()
    evenement_list = database.query(Evenement).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": evenement_list
        }

    result = []
    for evenement_item in evenement_list:
        gestionnaire_1_ids = database.query(Gestionnaire.id).filter(Gestionnaire.evenement_1_id == evenement_item.id).all()
        item_data = {
            "evenement": evenement_item,
            "gestionnaire_1_ids": [x[0] for x in gestionnaire_1_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/evenement/search/", response_model=None, tags=["Evenement"])
def search_evenement(
    database: Session = Depends(get_db)
) -> list:
    """Search Evenement entities by attributes"""
    query = database.query(Evenement)


    results = query.all()
    return results


@app.get("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def get_evenement(evenement_id: int, database: Session = Depends(get_db)) -> Evenement:
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")

    gestionnaire_1_ids = database.query(Gestionnaire.id).filter(Gestionnaire.evenement_1_id == db_evenement.id).all()
    response_data = {
        "evenement": db_evenement,
        "gestionnaire_1_ids": [x[0] for x in gestionnaire_1_ids]}
    return response_data



@app.post("/evenement/", response_model=None, tags=["Evenement"])
async def create_evenement(evenement_data: EvenementCreate, database: Session = Depends(get_db)) -> Evenement:

    if evenement_data.reservation is not None:
        db_reservation = database.query(Reservation).filter(Reservation.id == evenement_data.reservation).first()
        if not db_reservation:
            raise HTTPException(status_code=400, detail="Reservation not found")
    else:
        raise HTTPException(status_code=400, detail="Reservation ID is required")

    db_evenement = Evenement(
        emailreferent=evenement_data.emailreferent,        nom=evenement_data.nom,        statistique=evenement_data.statistique,        nbParticipants=evenement_data.nbParticipants,        description=evenement_data.description,        reservation_id=evenement_data.reservation        )

    database.add(db_evenement)
    database.commit()
    database.refresh(db_evenement)

    if evenement_data.gestionnaire_1:
        # Validate that all Gestionnaire IDs exist
        for gestionnaire_id in evenement_data.gestionnaire_1:
            db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
            if not db_gestionnaire:
                raise HTTPException(status_code=400, detail=f"Gestionnaire with id {gestionnaire_id} not found")

        # Update the related entities with the new foreign key
        database.query(Gestionnaire).filter(Gestionnaire.id.in_(evenement_data.gestionnaire_1)).update(
            {Gestionnaire.evenement_1_id: db_evenement.id}, synchronize_session=False
        )
        database.commit()



    gestionnaire_1_ids = database.query(Gestionnaire.id).filter(Gestionnaire.evenement_1_id == db_evenement.id).all()
    response_data = {
        "evenement": db_evenement,
        "gestionnaire_1_ids": [x[0] for x in gestionnaire_1_ids]    }
    return response_data


@app.post("/evenement/bulk/", response_model=None, tags=["Evenement"])
async def bulk_create_evenement(items: list[EvenementCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Evenement entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.reservation:
                raise ValueError("Reservation ID is required")

            db_evenement = Evenement(
                emailreferent=item_data.emailreferent,                nom=item_data.nom,                statistique=item_data.statistique,                nbParticipants=item_data.nbParticipants,                description=item_data.description,                reservation_id=item_data.reservation            )
            database.add(db_evenement)
            database.flush()  # Get ID without committing
            created_items.append(db_evenement.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Evenement entities"
    }


@app.delete("/evenement/bulk/", response_model=None, tags=["Evenement"])
async def bulk_delete_evenement(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Evenement entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_evenement = database.query(Evenement).filter(Evenement.id == item_id).first()
        if db_evenement:
            database.delete(db_evenement)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Evenement entities"
    }

@app.put("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def update_evenement(evenement_id: int, evenement_data: EvenementCreate, database: Session = Depends(get_db)) -> Evenement:
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")

    setattr(db_evenement, 'emailreferent', evenement_data.emailreferent)
    setattr(db_evenement, 'nom', evenement_data.nom)
    setattr(db_evenement, 'statistique', evenement_data.statistique)
    setattr(db_evenement, 'nbParticipants', evenement_data.nbParticipants)
    setattr(db_evenement, 'description', evenement_data.description)
    if evenement_data.reservation is not None:
        db_reservation = database.query(Reservation).filter(Reservation.id == evenement_data.reservation).first()
        if not db_reservation:
            raise HTTPException(status_code=400, detail="Reservation not found")
        setattr(db_evenement, 'reservation_id', evenement_data.reservation)
    if evenement_data.gestionnaire_1 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Gestionnaire).filter(Gestionnaire.evenement_1_id == db_evenement.id).update(
            {Gestionnaire.evenement_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if evenement_data.gestionnaire_1:
            # Validate that all IDs exist
            for gestionnaire_id in evenement_data.gestionnaire_1:
                db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
                if not db_gestionnaire:
                    raise HTTPException(status_code=400, detail=f"Gestionnaire with id {gestionnaire_id} not found")

            # Update the related entities with the new foreign key
            database.query(Gestionnaire).filter(Gestionnaire.id.in_(evenement_data.gestionnaire_1)).update(
                {Gestionnaire.evenement_1_id: db_evenement.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_evenement)

    gestionnaire_1_ids = database.query(Gestionnaire.id).filter(Gestionnaire.evenement_1_id == db_evenement.id).all()
    response_data = {
        "evenement": db_evenement,
        "gestionnaire_1_ids": [x[0] for x in gestionnaire_1_ids]    }
    return response_data


@app.delete("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def delete_evenement(evenement_id: int, database: Session = Depends(get_db)):
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")
    database.delete(db_evenement)
    database.commit()
    return db_evenement



############################################
#   Evenement Method Endpoints
############################################




@app.post("/evenement/methods/getDuree/", response_model=None, tags=["Evenement Methods"])
async def evenement_getDuree(
    database: Session = Depends(get_db)
):
    """
    Execute the getDuree class method on Evenement.
    This method operates on all Evenement entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Evenement",
            "method": "getDuree",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/evenement/methods/calculerNombreParticipantsTotal/", response_model=None, tags=["Evenement Methods"])
async def evenement_calculerNombreParticipantsTotal(
    database: Session = Depends(get_db)
):
    """
    Execute the calculerNombreParticipantsTotal class method on Evenement.
    This method operates on all Evenement entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Evenement",
            "method": "calculerNombreParticipantsTotal",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/evenement/methods/Evenement/", response_model=None, tags=["Evenement Methods"])
async def evenement_Evenement(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the Evenement class method on Evenement.
    This method operates on all Evenement entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nom: str    - description: str    - nbParticipants: int    - emailReferent: str    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nom = params.get('nom')
        description = params.get('description')
        nbParticipants = params.get('nbParticipants')
        emailReferent = params.get('emailReferent')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Evenement",
            "method": "Evenement",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/evenement/methods/genererStatistiques/", response_model=None, tags=["Evenement Methods"])
async def evenement_genererStatistiques(
    database: Session = Depends(get_db)
):
    """
    Execute the genererStatistiques class method on Evenement.
    This method operates on all Evenement entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Evenement",
            "method": "genererStatistiques",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/evenement/methods/ajouterReservation/", response_model=None, tags=["Evenement Methods"])
async def evenement_ajouterReservation(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the ajouterReservation class method on Evenement.
    This method operates on all Evenement entities or performs class-level operations.

    Parameters (pass as JSON body):
    - reservation: Any    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        reservation = params.get('reservation')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Evenement",
            "method": "ajouterReservation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Gestionnaire functions
#
############################################

@app.get("/gestionnaire/", response_model=None, tags=["Gestionnaire"])
def get_all_gestionnaire(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Gestionnaire)
        query = query.options(joinedload(Gestionnaire.centrecongres))
        query = query.options(joinedload(Gestionnaire.evenement_1))
        gestionnaire_list = query.all()

        # Serialize with relationships included
        result = []
        for gestionnaire_item in gestionnaire_list:
            item_dict = gestionnaire_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if gestionnaire_item.centrecongres:
                related_obj = gestionnaire_item.centrecongres
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['centrecongres'] = related_dict
            else:
                item_dict['centrecongres'] = None
            if gestionnaire_item.evenement_1:
                related_obj = gestionnaire_item.evenement_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['evenement_1'] = related_dict
            else:
                item_dict['evenement_1'] = None

            # Add many-to-many and one-to-many relationship objects (full details)
            reservation_list = database.query(Reservation).filter(Reservation.gestionnaire_2_id == gestionnaire_item.id).all()
            item_dict['reservation_3'] = []
            for reservation_obj in reservation_list:
                reservation_dict = reservation_obj.__dict__.copy()
                reservation_dict.pop('_sa_instance_state', None)
                item_dict['reservation_3'].append(reservation_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Gestionnaire).all()


@app.get("/gestionnaire/count/", response_model=None, tags=["Gestionnaire"])
def get_count_gestionnaire(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Gestionnaire entities"""
    count = database.query(Gestionnaire).count()
    return {"count": count}


@app.get("/gestionnaire/paginated/", response_model=None, tags=["Gestionnaire"])
def get_paginated_gestionnaire(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Gestionnaire entities"""
    total = database.query(Gestionnaire).count()
    gestionnaire_list = database.query(Gestionnaire).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": gestionnaire_list
        }

    result = []
    for gestionnaire_item in gestionnaire_list:
        reservation_3_ids = database.query(Reservation.id).filter(Reservation.gestionnaire_2_id == gestionnaire_item.id).all()
        item_data = {
            "gestionnaire": gestionnaire_item,
            "reservation_3_ids": [x[0] for x in reservation_3_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/gestionnaire/search/", response_model=None, tags=["Gestionnaire"])
def search_gestionnaire(
    database: Session = Depends(get_db)
) -> list:
    """Search Gestionnaire entities by attributes"""
    query = database.query(Gestionnaire)


    results = query.all()
    return results


@app.get("/gestionnaire/{gestionnaire_id}/", response_model=None, tags=["Gestionnaire"])
async def get_gestionnaire(gestionnaire_id: int, database: Session = Depends(get_db)) -> Gestionnaire:
    db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
    if db_gestionnaire is None:
        raise HTTPException(status_code=404, detail="Gestionnaire not found")

    reservation_3_ids = database.query(Reservation.id).filter(Reservation.gestionnaire_2_id == db_gestionnaire.id).all()
    response_data = {
        "gestionnaire": db_gestionnaire,
        "reservation_3_ids": [x[0] for x in reservation_3_ids]}
    return response_data



@app.post("/gestionnaire/", response_model=None, tags=["Gestionnaire"])
async def create_gestionnaire(gestionnaire_data: GestionnaireCreate, database: Session = Depends(get_db)) -> Gestionnaire:

    if gestionnaire_data.centrecongres is not None:
        db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == gestionnaire_data.centrecongres).first()
        if not db_centrecongres:
            raise HTTPException(status_code=400, detail="CentreCongres not found")
    else:
        raise HTTPException(status_code=400, detail="CentreCongres ID is required")
    if gestionnaire_data.evenement_1 is not None:
        db_evenement_1 = database.query(Evenement).filter(Evenement.id == gestionnaire_data.evenement_1).first()
        if not db_evenement_1:
            raise HTTPException(status_code=400, detail="Evenement not found")
    else:
        raise HTTPException(status_code=400, detail="Evenement ID is required")

    db_gestionnaire = Gestionnaire(
        attribut=gestionnaire_data.attribut,        centrecongres_id=gestionnaire_data.centrecongres,        evenement_1_id=gestionnaire_data.evenement_1        )

    database.add(db_gestionnaire)
    database.commit()
    database.refresh(db_gestionnaire)

    if gestionnaire_data.reservation_3:
        # Validate that all Reservation IDs exist
        for reservation_id in gestionnaire_data.reservation_3:
            db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
            if not db_reservation:
                raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

        # Update the related entities with the new foreign key
        database.query(Reservation).filter(Reservation.id.in_(gestionnaire_data.reservation_3)).update(
            {Reservation.gestionnaire_2_id: db_gestionnaire.id}, synchronize_session=False
        )
        database.commit()



    reservation_3_ids = database.query(Reservation.id).filter(Reservation.gestionnaire_2_id == db_gestionnaire.id).all()
    response_data = {
        "gestionnaire": db_gestionnaire,
        "reservation_3_ids": [x[0] for x in reservation_3_ids]    }
    return response_data


@app.post("/gestionnaire/bulk/", response_model=None, tags=["Gestionnaire"])
async def bulk_create_gestionnaire(items: list[GestionnaireCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Gestionnaire entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.centrecongres:
                raise ValueError("CentreCongres ID is required")
            if not item_data.evenement_1:
                raise ValueError("Evenement ID is required")

            db_gestionnaire = Gestionnaire(
                attribut=item_data.attribut,                centrecongres_id=item_data.centrecongres,                evenement_1_id=item_data.evenement_1            )
            database.add(db_gestionnaire)
            database.flush()  # Get ID without committing
            created_items.append(db_gestionnaire.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Gestionnaire entities"
    }


@app.delete("/gestionnaire/bulk/", response_model=None, tags=["Gestionnaire"])
async def bulk_delete_gestionnaire(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Gestionnaire entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == item_id).first()
        if db_gestionnaire:
            database.delete(db_gestionnaire)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Gestionnaire entities"
    }

@app.put("/gestionnaire/{gestionnaire_id}/", response_model=None, tags=["Gestionnaire"])
async def update_gestionnaire(gestionnaire_id: int, gestionnaire_data: GestionnaireCreate, database: Session = Depends(get_db)) -> Gestionnaire:
    db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
    if db_gestionnaire is None:
        raise HTTPException(status_code=404, detail="Gestionnaire not found")

    setattr(db_gestionnaire, 'attribut', gestionnaire_data.attribut)
    if gestionnaire_data.centrecongres is not None:
        db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == gestionnaire_data.centrecongres).first()
        if not db_centrecongres:
            raise HTTPException(status_code=400, detail="CentreCongres not found")
        setattr(db_gestionnaire, 'centrecongres_id', gestionnaire_data.centrecongres)
    if gestionnaire_data.evenement_1 is not None:
        db_evenement_1 = database.query(Evenement).filter(Evenement.id == gestionnaire_data.evenement_1).first()
        if not db_evenement_1:
            raise HTTPException(status_code=400, detail="Evenement not found")
        setattr(db_gestionnaire, 'evenement_1_id', gestionnaire_data.evenement_1)
    if gestionnaire_data.reservation_3 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Reservation).filter(Reservation.gestionnaire_2_id == db_gestionnaire.id).update(
            {Reservation.gestionnaire_2_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if gestionnaire_data.reservation_3:
            # Validate that all IDs exist
            for reservation_id in gestionnaire_data.reservation_3:
                db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
                if not db_reservation:
                    raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

            # Update the related entities with the new foreign key
            database.query(Reservation).filter(Reservation.id.in_(gestionnaire_data.reservation_3)).update(
                {Reservation.gestionnaire_2_id: db_gestionnaire.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_gestionnaire)

    reservation_3_ids = database.query(Reservation.id).filter(Reservation.gestionnaire_2_id == db_gestionnaire.id).all()
    response_data = {
        "gestionnaire": db_gestionnaire,
        "reservation_3_ids": [x[0] for x in reservation_3_ids]    }
    return response_data


@app.delete("/gestionnaire/{gestionnaire_id}/", response_model=None, tags=["Gestionnaire"])
async def delete_gestionnaire(gestionnaire_id: int, database: Session = Depends(get_db)):
    db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
    if db_gestionnaire is None:
        raise HTTPException(status_code=404, detail="Gestionnaire not found")
    database.delete(db_gestionnaire)
    database.commit()
    return db_gestionnaire



############################################
#   Gestionnaire Method Endpoints
############################################




@app.post("/gestionnaire/methods/creerReservation/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_creerReservation(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the creerReservation class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebut: date    - dateFin: date    - salle: Salle    - evenement: Evenement    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebut = params.get('dateDebut')
        dateFin = params.get('dateFin')
        salle = await get_salle(params.get('salle'), database)
        evenement = await get_evenement(params.get('evenement'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "creerReservation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/consulterStatistiques/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_consulterStatistiques(
    database: Session = Depends(get_db)
):
    """
    Execute the consulterStatistiques class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "consulterStatistiques",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/definirTarif/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_definirTarif(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the definirTarif class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nomSaison: str    - prixUnitaire: float    - dateDebut: date    - dateFin: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nomSaison = params.get('nomSaison')
        prixUnitaire = params.get('prixUnitaire')
        dateDebut = params.get('dateDebut')
        dateFin = params.get('dateFin')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "definirTarif",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/Gestionnaire/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_Gestionnaire(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the Gestionnaire class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - attribute: str    - centre: CentreCongres    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        attribute = params.get('attribute')
        centre = await get_centrecongres(params.get('centre'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "Gestionnaire",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/annulerReservation/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_annulerReservation(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the annulerReservation class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - reservation: Any    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        reservation = params.get('reservation')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "annulerReservation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/gestionnaire/methods/modifierReservation/", response_model=None, tags=["Gestionnaire Methods"])
async def gestionnaire_modifierReservation(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the modifierReservation class method on Gestionnaire.
    This method operates on all Gestionnaire entities or performs class-level operations.

    Parameters (pass as JSON body):
    - reservation: Any    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        reservation = params.get('reservation')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Gestionnaire",
            "method": "modifierReservation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   CentreCongres functions
#
############################################

@app.get("/centrecongres/", response_model=None, tags=["CentreCongres"])
def get_all_centrecongres(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(CentreCongres)
        centrecongres_list = query.all()

        # Serialize with relationships included
        result = []
        for centrecongres_item in centrecongres_list:
            item_dict = centrecongres_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)

            # Add many-to-many and one-to-many relationship objects (full details)
            gestionnaire_list = database.query(Gestionnaire).filter(Gestionnaire.centrecongres_id == centrecongres_item.id).all()
            item_dict['gestionnaire'] = []
            for gestionnaire_obj in gestionnaire_list:
                gestionnaire_dict = gestionnaire_obj.__dict__.copy()
                gestionnaire_dict.pop('_sa_instance_state', None)
                item_dict['gestionnaire'].append(gestionnaire_dict)
            salle_list = database.query(Salle).filter(Salle.centrecongres_1_id == centrecongres_item.id).all()
            item_dict['salle'] = []
            for salle_obj in salle_list:
                salle_dict = salle_obj.__dict__.copy()
                salle_dict.pop('_sa_instance_state', None)
                item_dict['salle'].append(salle_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(CentreCongres).all()


@app.get("/centrecongres/count/", response_model=None, tags=["CentreCongres"])
def get_count_centrecongres(database: Session = Depends(get_db)) -> dict:
    """Get the total count of CentreCongres entities"""
    count = database.query(CentreCongres).count()
    return {"count": count}


@app.get("/centrecongres/paginated/", response_model=None, tags=["CentreCongres"])
def get_paginated_centrecongres(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of CentreCongres entities"""
    total = database.query(CentreCongres).count()
    centrecongres_list = database.query(CentreCongres).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": centrecongres_list
        }

    result = []
    for centrecongres_item in centrecongres_list:
        gestionnaire_ids = database.query(Gestionnaire.id).filter(Gestionnaire.centrecongres_id == centrecongres_item.id).all()
        salle_ids = database.query(Salle.id).filter(Salle.centrecongres_1_id == centrecongres_item.id).all()
        item_data = {
            "centrecongres": centrecongres_item,
            "gestionnaire_ids": [x[0] for x in gestionnaire_ids],            "salle_ids": [x[0] for x in salle_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/centrecongres/search/", response_model=None, tags=["CentreCongres"])
def search_centrecongres(
    database: Session = Depends(get_db)
) -> list:
    """Search CentreCongres entities by attributes"""
    query = database.query(CentreCongres)


    results = query.all()
    return results


@app.get("/centrecongres/{centrecongres_id}/", response_model=None, tags=["CentreCongres"])
async def get_centrecongres(centrecongres_id: int, database: Session = Depends(get_db)) -> CentreCongres:
    db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == centrecongres_id).first()
    if db_centrecongres is None:
        raise HTTPException(status_code=404, detail="CentreCongres not found")

    gestionnaire_ids = database.query(Gestionnaire.id).filter(Gestionnaire.centrecongres_id == db_centrecongres.id).all()
    salle_ids = database.query(Salle.id).filter(Salle.centrecongres_1_id == db_centrecongres.id).all()
    response_data = {
        "centrecongres": db_centrecongres,
        "gestionnaire_ids": [x[0] for x in gestionnaire_ids],        "salle_ids": [x[0] for x in salle_ids]}
    return response_data



@app.post("/centrecongres/", response_model=None, tags=["CentreCongres"])
async def create_centrecongres(centrecongres_data: CentreCongresCreate, database: Session = Depends(get_db)) -> CentreCongres:


    db_centrecongres = CentreCongres(
        nom=centrecongres_data.nom,        adresse=centrecongres_data.adresse        )

    database.add(db_centrecongres)
    database.commit()
    database.refresh(db_centrecongres)

    if centrecongres_data.gestionnaire:
        # Validate that all Gestionnaire IDs exist
        for gestionnaire_id in centrecongres_data.gestionnaire:
            db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
            if not db_gestionnaire:
                raise HTTPException(status_code=400, detail=f"Gestionnaire with id {gestionnaire_id} not found")

        # Update the related entities with the new foreign key
        database.query(Gestionnaire).filter(Gestionnaire.id.in_(centrecongres_data.gestionnaire)).update(
            {Gestionnaire.centrecongres_id: db_centrecongres.id}, synchronize_session=False
        )
        database.commit()
    if centrecongres_data.salle:
        # Validate that all Salle IDs exist
        for salle_id in centrecongres_data.salle:
            db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
            if not db_salle:
                raise HTTPException(status_code=400, detail=f"Salle with id {salle_id} not found")

        # Update the related entities with the new foreign key
        database.query(Salle).filter(Salle.id.in_(centrecongres_data.salle)).update(
            {Salle.centrecongres_1_id: db_centrecongres.id}, synchronize_session=False
        )
        database.commit()



    gestionnaire_ids = database.query(Gestionnaire.id).filter(Gestionnaire.centrecongres_id == db_centrecongres.id).all()
    salle_ids = database.query(Salle.id).filter(Salle.centrecongres_1_id == db_centrecongres.id).all()
    response_data = {
        "centrecongres": db_centrecongres,
        "gestionnaire_ids": [x[0] for x in gestionnaire_ids],        "salle_ids": [x[0] for x in salle_ids]    }
    return response_data


@app.post("/centrecongres/bulk/", response_model=None, tags=["CentreCongres"])
async def bulk_create_centrecongres(items: list[CentreCongresCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple CentreCongres entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_centrecongres = CentreCongres(
                nom=item_data.nom,                adresse=item_data.adresse            )
            database.add(db_centrecongres)
            database.flush()  # Get ID without committing
            created_items.append(db_centrecongres.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} CentreCongres entities"
    }


@app.delete("/centrecongres/bulk/", response_model=None, tags=["CentreCongres"])
async def bulk_delete_centrecongres(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple CentreCongres entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == item_id).first()
        if db_centrecongres:
            database.delete(db_centrecongres)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} CentreCongres entities"
    }

@app.put("/centrecongres/{centrecongres_id}/", response_model=None, tags=["CentreCongres"])
async def update_centrecongres(centrecongres_id: int, centrecongres_data: CentreCongresCreate, database: Session = Depends(get_db)) -> CentreCongres:
    db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == centrecongres_id).first()
    if db_centrecongres is None:
        raise HTTPException(status_code=404, detail="CentreCongres not found")

    setattr(db_centrecongres, 'nom', centrecongres_data.nom)
    setattr(db_centrecongres, 'adresse', centrecongres_data.adresse)
    if centrecongres_data.gestionnaire is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Gestionnaire).filter(Gestionnaire.centrecongres_id == db_centrecongres.id).update(
            {Gestionnaire.centrecongres_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if centrecongres_data.gestionnaire:
            # Validate that all IDs exist
            for gestionnaire_id in centrecongres_data.gestionnaire:
                db_gestionnaire = database.query(Gestionnaire).filter(Gestionnaire.id == gestionnaire_id).first()
                if not db_gestionnaire:
                    raise HTTPException(status_code=400, detail=f"Gestionnaire with id {gestionnaire_id} not found")

            # Update the related entities with the new foreign key
            database.query(Gestionnaire).filter(Gestionnaire.id.in_(centrecongres_data.gestionnaire)).update(
                {Gestionnaire.centrecongres_id: db_centrecongres.id}, synchronize_session=False
            )
    if centrecongres_data.salle is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Salle).filter(Salle.centrecongres_1_id == db_centrecongres.id).update(
            {Salle.centrecongres_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if centrecongres_data.salle:
            # Validate that all IDs exist
            for salle_id in centrecongres_data.salle:
                db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
                if not db_salle:
                    raise HTTPException(status_code=400, detail=f"Salle with id {salle_id} not found")

            # Update the related entities with the new foreign key
            database.query(Salle).filter(Salle.id.in_(centrecongres_data.salle)).update(
                {Salle.centrecongres_1_id: db_centrecongres.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_centrecongres)

    gestionnaire_ids = database.query(Gestionnaire.id).filter(Gestionnaire.centrecongres_id == db_centrecongres.id).all()
    salle_ids = database.query(Salle.id).filter(Salle.centrecongres_1_id == db_centrecongres.id).all()
    response_data = {
        "centrecongres": db_centrecongres,
        "gestionnaire_ids": [x[0] for x in gestionnaire_ids],        "salle_ids": [x[0] for x in salle_ids]    }
    return response_data


@app.delete("/centrecongres/{centrecongres_id}/", response_model=None, tags=["CentreCongres"])
async def delete_centrecongres(centrecongres_id: int, database: Session = Depends(get_db)):
    db_centrecongres = database.query(CentreCongres).filter(CentreCongres.id == centrecongres_id).first()
    if db_centrecongres is None:
        raise HTTPException(status_code=404, detail="CentreCongres not found")
    database.delete(db_centrecongres)
    database.commit()
    return db_centrecongres



############################################
#   CentreCongres Method Endpoints
############################################




@app.post("/centrecongres/methods/CentreCongres/", response_model=None, tags=["CentreCongres Methods"])
async def centrecongres_CentreCongres(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the CentreCongres class method on CentreCongres.
    This method operates on all CentreCongres entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nom: str    - adresse: str    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nom = params.get('nom')
        adresse = params.get('adresse')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "CentreCongres",
            "method": "CentreCongres",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Salle functions
#
############################################

@app.get("/salle/", response_model=None, tags=["Salle"])
def get_all_salle(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Salle)
        query = query.options(joinedload(Salle.tarif_2))
        query = query.options(joinedload(Salle.centrecongres_1))
        query = query.options(joinedload(Salle.reservation_2))
        salle_list = query.all()

        # Serialize with relationships included
        result = []
        for salle_item in salle_list:
            item_dict = salle_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if salle_item.tarif_2:
                related_obj = salle_item.tarif_2
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['tarif_2'] = related_dict
            else:
                item_dict['tarif_2'] = None
            if salle_item.centrecongres_1:
                related_obj = salle_item.centrecongres_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['centrecongres_1'] = related_dict
            else:
                item_dict['centrecongres_1'] = None
            if salle_item.reservation_2:
                related_obj = salle_item.reservation_2
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation_2'] = related_dict
            else:
                item_dict['reservation_2'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Salle).all()


@app.get("/salle/count/", response_model=None, tags=["Salle"])
def get_count_salle(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Salle entities"""
    count = database.query(Salle).count()
    return {"count": count}


@app.get("/salle/paginated/", response_model=None, tags=["Salle"])
def get_paginated_salle(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Salle entities"""
    total = database.query(Salle).count()
    salle_list = database.query(Salle).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": salle_list
    }


@app.get("/salle/search/", response_model=None, tags=["Salle"])
def search_salle(
    database: Session = Depends(get_db)
) -> list:
    """Search Salle entities by attributes"""
    query = database.query(Salle)


    results = query.all()
    return results


@app.get("/salle/{salle_id}/", response_model=None, tags=["Salle"])
async def get_salle(salle_id: int, database: Session = Depends(get_db)) -> Salle:
    db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
    if db_salle is None:
        raise HTTPException(status_code=404, detail="Salle not found")

    response_data = {
        "salle": db_salle,
}
    return response_data



@app.post("/salle/", response_model=None, tags=["Salle"])
async def create_salle(salle_data: SalleCreate, database: Session = Depends(get_db)) -> Salle:

    if salle_data.tarif_2 is not None:
        db_tarif_2 = database.query(Tarif).filter(Tarif.id == salle_data.tarif_2).first()
        if not db_tarif_2:
            raise HTTPException(status_code=400, detail="Tarif not found")
    else:
        raise HTTPException(status_code=400, detail="Tarif ID is required")
    if salle_data.centrecongres_1 is not None:
        db_centrecongres_1 = database.query(CentreCongres).filter(CentreCongres.id == salle_data.centrecongres_1).first()
        if not db_centrecongres_1:
            raise HTTPException(status_code=400, detail="CentreCongres not found")
    else:
        raise HTTPException(status_code=400, detail="CentreCongres ID is required")
    if salle_data.reservation_2 :
        db_reservation_2 = database.query(Reservation).filter(Reservation.id == salle_data.reservation_2).first()
        if not db_reservation_2:
            raise HTTPException(status_code=400, detail="Reservation not found")

    db_salle = Salle(
        capacite=salle_data.capacite,        nom=salle_data.nom,        prixBase=salle_data.prixBase,        type=salle_data.type,        tarif_2_id=salle_data.tarif_2,        centrecongres_1_id=salle_data.centrecongres_1,        reservation_2_id=salle_data.reservation_2        )

    database.add(db_salle)
    database.commit()
    database.refresh(db_salle)




    return db_salle


@app.post("/salle/bulk/", response_model=None, tags=["Salle"])
async def bulk_create_salle(items: list[SalleCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Salle entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.tarif_2:
                raise ValueError("Tarif ID is required")
            if not item_data.centrecongres_1:
                raise ValueError("CentreCongres ID is required")

            db_salle = Salle(
                capacite=item_data.capacite,                nom=item_data.nom,                prixBase=item_data.prixBase,                type=item_data.type,                tarif_2_id=item_data.tarif_2,                centrecongres_1_id=item_data.centrecongres_1,                reservation_2_id=item_data.reservation_2            )
            database.add(db_salle)
            database.flush()  # Get ID without committing
            created_items.append(db_salle.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Salle entities"
    }


@app.delete("/salle/bulk/", response_model=None, tags=["Salle"])
async def bulk_delete_salle(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Salle entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_salle = database.query(Salle).filter(Salle.id == item_id).first()
        if db_salle:
            database.delete(db_salle)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Salle entities"
    }

@app.put("/salle/{salle_id}/", response_model=None, tags=["Salle"])
async def update_salle(salle_id: int, salle_data: SalleCreate, database: Session = Depends(get_db)) -> Salle:
    db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
    if db_salle is None:
        raise HTTPException(status_code=404, detail="Salle not found")

    setattr(db_salle, 'capacite', salle_data.capacite)
    setattr(db_salle, 'nom', salle_data.nom)
    setattr(db_salle, 'prixBase', salle_data.prixBase)
    setattr(db_salle, 'type', salle_data.type)
    if salle_data.tarif_2 is not None:
        db_tarif_2 = database.query(Tarif).filter(Tarif.id == salle_data.tarif_2).first()
        if not db_tarif_2:
            raise HTTPException(status_code=400, detail="Tarif not found")
        setattr(db_salle, 'tarif_2_id', salle_data.tarif_2)
    if salle_data.centrecongres_1 is not None:
        db_centrecongres_1 = database.query(CentreCongres).filter(CentreCongres.id == salle_data.centrecongres_1).first()
        if not db_centrecongres_1:
            raise HTTPException(status_code=400, detail="CentreCongres not found")
        setattr(db_salle, 'centrecongres_1_id', salle_data.centrecongres_1)
    if salle_data.reservation_2 is not None:
        db_reservation_2 = database.query(Reservation).filter(Reservation.id == salle_data.reservation_2).first()
        if not db_reservation_2:
            raise HTTPException(status_code=400, detail="Reservation not found")
        setattr(db_salle, 'reservation_2_id', salle_data.reservation_2)
    else:
        setattr(db_salle, 'reservation_2_id', None)
    database.commit()
    database.refresh(db_salle)

    return db_salle


@app.delete("/salle/{salle_id}/", response_model=None, tags=["Salle"])
async def delete_salle(salle_id: int, database: Session = Depends(get_db)):
    db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
    if db_salle is None:
        raise HTTPException(status_code=404, detail="Salle not found")
    database.delete(db_salle)
    database.commit()
    return db_salle



############################################
#   Salle Method Endpoints
############################################




@app.post("/salle/methods/estDisponible/", response_model=None, tags=["Salle Methods"])
async def salle_estDisponible(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the estDisponible class method on Salle.
    This method operates on all Salle entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebutParam: date    - dateFinParam: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebutParam = params.get('dateDebutParam')
        dateFinParam = params.get('dateFinParam')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Salle",
            "method": "estDisponible",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/salle/methods/ajouterIndisponibilite/", response_model=None, tags=["Salle Methods"])
async def salle_ajouterIndisponibilite(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the ajouterIndisponibilite class method on Salle.
    This method operates on all Salle entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebutParam: date    - dateFinParam: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebutParam = params.get('dateDebutParam')
        dateFinParam = params.get('dateFinParam')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Salle",
            "method": "ajouterIndisponibilite",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/salle/methods/Salle/", response_model=None, tags=["Salle Methods"])
async def salle_Salle(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the Salle class method on Salle.
    This method operates on all Salle entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nom: str    - type: str    - capacite: int    - prixBase: float    - centre: CentreCongres    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nom = params.get('nom')
        type = params.get('type')
        capacite = params.get('capacite')
        prixBase = params.get('prixBase')
        centre = await get_centrecongres(params.get('centre'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Salle",
            "method": "Salle",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/salle/{salle_id}/methods/verifierCapacite/", response_model=None, tags=["Salle Methods"])
async def execute_salle_verifierCapacite(
    salle_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the verifierCapacite method on a Salle instance.

    Parameters:
    - nbParticipants: Any    """
    # Retrieve the entity from the database
    _salle_object = database.query(Salle).filter(Salle.id == salle_id).first()
    if _salle_object is None:
        raise HTTPException(status_code=404, detail="Salle not found")

    # Prepare method parameters
    nbParticipants = params.get('nbParticipants')

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_salle_object):
            """Add your docstring here."""
            # Add your implementation here
            pass


        result = await wrapper(_salle_object)
        # Commit DB
        database.commit()
        database.refresh(_salle_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "salle_id": salle_id,
            "method": "verifierCapacite",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





@app.post("/salle/methods/calculerCout/", response_model=None, tags=["Salle Methods"])
async def salle_calculerCout(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the calculerCout class method on Salle.
    This method operates on all Salle entities or performs class-level operations.

    Parameters (pass as JSON body):
    - duree: Any    - tarif: Any    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        duree = params.get('duree')
        tarif = params.get('tarif')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Salle",
            "method": "calculerCout",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")




############################################
#
#   Reservation functions
#
############################################

@app.get("/reservation/", response_model=None, tags=["Reservation"])
def get_all_reservation(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Reservation)
        query = query.options(joinedload(Reservation.tarif_1))
        query = query.options(joinedload(Reservation.gestionnaire_2))
        reservation_list = query.all()

        # Serialize with relationships included
        result = []
        for reservation_item in reservation_list:
            item_dict = reservation_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if reservation_item.tarif_1:
                related_obj = reservation_item.tarif_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['tarif_1'] = related_dict
            else:
                item_dict['tarif_1'] = None
            if reservation_item.gestionnaire_2:
                related_obj = reservation_item.gestionnaire_2
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['gestionnaire_2'] = related_dict
            else:
                item_dict['gestionnaire_2'] = None

            # Add many-to-many and one-to-many relationship objects (full details)
            ressource_list = database.query(Ressource).filter(Ressource.reservation_1_id == reservation_item.id).all()
            item_dict['ressource'] = []
            for ressource_obj in ressource_list:
                ressource_dict = ressource_obj.__dict__.copy()
                ressource_dict.pop('_sa_instance_state', None)
                item_dict['ressource'].append(ressource_dict)
            evenement_list = database.query(Evenement).filter(Evenement.reservation_id == reservation_item.id).all()
            item_dict['evenement'] = []
            for evenement_obj in evenement_list:
                evenement_dict = evenement_obj.__dict__.copy()
                evenement_dict.pop('_sa_instance_state', None)
                item_dict['evenement'].append(evenement_dict)
            salle_list = database.query(Salle).filter(Salle.reservation_2_id == reservation_item.id).all()
            item_dict['salle_1'] = []
            for salle_obj in salle_list:
                salle_dict = salle_obj.__dict__.copy()
                salle_dict.pop('_sa_instance_state', None)
                item_dict['salle_1'].append(salle_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Reservation).all()


@app.get("/reservation/count/", response_model=None, tags=["Reservation"])
def get_count_reservation(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Reservation entities"""
    count = database.query(Reservation).count()
    return {"count": count}


@app.get("/reservation/paginated/", response_model=None, tags=["Reservation"])
def get_paginated_reservation(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Reservation entities"""
    total = database.query(Reservation).count()
    reservation_list = database.query(Reservation).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": reservation_list
        }

    result = []
    for reservation_item in reservation_list:
        ressource_ids = database.query(Ressource.id).filter(Ressource.reservation_1_id == reservation_item.id).all()
        evenement_ids = database.query(Evenement.id).filter(Evenement.reservation_id == reservation_item.id).all()
        salle_1_ids = database.query(Salle.id).filter(Salle.reservation_2_id == reservation_item.id).all()
        item_data = {
            "reservation": reservation_item,
            "ressource_ids": [x[0] for x in ressource_ids],            "evenement_ids": [x[0] for x in evenement_ids],            "salle_1_ids": [x[0] for x in salle_1_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/reservation/search/", response_model=None, tags=["Reservation"])
def search_reservation(
    database: Session = Depends(get_db)
) -> list:
    """Search Reservation entities by attributes"""
    query = database.query(Reservation)


    results = query.all()
    return results


@app.get("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def get_reservation(reservation_id: int, database: Session = Depends(get_db)) -> Reservation:
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    ressource_ids = database.query(Ressource.id).filter(Ressource.reservation_1_id == db_reservation.id).all()
    evenement_ids = database.query(Evenement.id).filter(Evenement.reservation_id == db_reservation.id).all()
    salle_1_ids = database.query(Salle.id).filter(Salle.reservation_2_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "ressource_ids": [x[0] for x in ressource_ids],        "evenement_ids": [x[0] for x in evenement_ids],        "salle_1_ids": [x[0] for x in salle_1_ids]}
    return response_data



@app.post("/reservation/", response_model=None, tags=["Reservation"])
async def create_reservation(reservation_data: ReservationCreate, database: Session = Depends(get_db)) -> Reservation:

    if reservation_data.tarif_1 is not None:
        db_tarif_1 = database.query(Tarif).filter(Tarif.id == reservation_data.tarif_1).first()
        if not db_tarif_1:
            raise HTTPException(status_code=400, detail="Tarif not found")
    else:
        raise HTTPException(status_code=400, detail="Tarif ID is required")
    if reservation_data.gestionnaire_2 is not None:
        db_gestionnaire_2 = database.query(Gestionnaire).filter(Gestionnaire.id == reservation_data.gestionnaire_2).first()
        if not db_gestionnaire_2:
            raise HTTPException(status_code=400, detail="Gestionnaire not found")
    else:
        raise HTTPException(status_code=400, detail="Gestionnaire ID is required")

    db_reservation = Reservation(
        dateDebut=reservation_data.dateDebut,        dateLimiteConfirmation=reservation_data.dateLimiteConfirmation,        estConfirmer=reservation_data.estConfirmer,        dateFin=reservation_data.dateFin,        tarif_1_id=reservation_data.tarif_1,        gestionnaire_2_id=reservation_data.gestionnaire_2        )

    database.add(db_reservation)
    database.commit()
    database.refresh(db_reservation)

    if reservation_data.ressource:
        # Validate that all Ressource IDs exist
        for ressource_id in reservation_data.ressource:
            db_ressource = database.query(Ressource).filter(Ressource.id == ressource_id).first()
            if not db_ressource:
                raise HTTPException(status_code=400, detail=f"Ressource with id {ressource_id} not found")

        # Update the related entities with the new foreign key
        database.query(Ressource).filter(Ressource.id.in_(reservation_data.ressource)).update(
            {Ressource.reservation_1_id: db_reservation.id}, synchronize_session=False
        )
        database.commit()
    if reservation_data.evenement:
        # Validate that all Evenement IDs exist
        for evenement_id in reservation_data.evenement:
            db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
            if not db_evenement:
                raise HTTPException(status_code=400, detail=f"Evenement with id {evenement_id} not found")

        # Update the related entities with the new foreign key
        database.query(Evenement).filter(Evenement.id.in_(reservation_data.evenement)).update(
            {Evenement.reservation_id: db_reservation.id}, synchronize_session=False
        )
        database.commit()
    if reservation_data.salle_1:
        # Validate that all Salle IDs exist
        for salle_id in reservation_data.salle_1:
            db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
            if not db_salle:
                raise HTTPException(status_code=400, detail=f"Salle with id {salle_id} not found")

        # Update the related entities with the new foreign key
        database.query(Salle).filter(Salle.id.in_(reservation_data.salle_1)).update(
            {Salle.reservation_2_id: db_reservation.id}, synchronize_session=False
        )
        database.commit()



    ressource_ids = database.query(Ressource.id).filter(Ressource.reservation_1_id == db_reservation.id).all()
    evenement_ids = database.query(Evenement.id).filter(Evenement.reservation_id == db_reservation.id).all()
    salle_1_ids = database.query(Salle.id).filter(Salle.reservation_2_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "ressource_ids": [x[0] for x in ressource_ids],        "evenement_ids": [x[0] for x in evenement_ids],        "salle_1_ids": [x[0] for x in salle_1_ids]    }
    return response_data


@app.post("/reservation/bulk/", response_model=None, tags=["Reservation"])
async def bulk_create_reservation(items: list[ReservationCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Reservation entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.tarif_1:
                raise ValueError("Tarif ID is required")
            if not item_data.gestionnaire_2:
                raise ValueError("Gestionnaire ID is required")

            db_reservation = Reservation(
                dateDebut=item_data.dateDebut,                dateLimiteConfirmation=item_data.dateLimiteConfirmation,                estConfirmer=item_data.estConfirmer,                dateFin=item_data.dateFin,                tarif_1_id=item_data.tarif_1,                gestionnaire_2_id=item_data.gestionnaire_2            )
            database.add(db_reservation)
            database.flush()  # Get ID without committing
            created_items.append(db_reservation.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Reservation entities"
    }


@app.delete("/reservation/bulk/", response_model=None, tags=["Reservation"])
async def bulk_delete_reservation(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Reservation entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_reservation = database.query(Reservation).filter(Reservation.id == item_id).first()
        if db_reservation:
            database.delete(db_reservation)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Reservation entities"
    }

@app.put("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def update_reservation(reservation_id: int, reservation_data: ReservationCreate, database: Session = Depends(get_db)) -> Reservation:
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    setattr(db_reservation, 'dateDebut', reservation_data.dateDebut)
    setattr(db_reservation, 'dateLimiteConfirmation', reservation_data.dateLimiteConfirmation)
    setattr(db_reservation, 'estConfirmer', reservation_data.estConfirmer)
    setattr(db_reservation, 'dateFin', reservation_data.dateFin)
    if reservation_data.tarif_1 is not None:
        db_tarif_1 = database.query(Tarif).filter(Tarif.id == reservation_data.tarif_1).first()
        if not db_tarif_1:
            raise HTTPException(status_code=400, detail="Tarif not found")
        setattr(db_reservation, 'tarif_1_id', reservation_data.tarif_1)
    if reservation_data.gestionnaire_2 is not None:
        db_gestionnaire_2 = database.query(Gestionnaire).filter(Gestionnaire.id == reservation_data.gestionnaire_2).first()
        if not db_gestionnaire_2:
            raise HTTPException(status_code=400, detail="Gestionnaire not found")
        setattr(db_reservation, 'gestionnaire_2_id', reservation_data.gestionnaire_2)
    if reservation_data.ressource is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Ressource).filter(Ressource.reservation_1_id == db_reservation.id).update(
            {Ressource.reservation_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if reservation_data.ressource:
            # Validate that all IDs exist
            for ressource_id in reservation_data.ressource:
                db_ressource = database.query(Ressource).filter(Ressource.id == ressource_id).first()
                if not db_ressource:
                    raise HTTPException(status_code=400, detail=f"Ressource with id {ressource_id} not found")

            # Update the related entities with the new foreign key
            database.query(Ressource).filter(Ressource.id.in_(reservation_data.ressource)).update(
                {Ressource.reservation_1_id: db_reservation.id}, synchronize_session=False
            )
    if reservation_data.evenement is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Evenement).filter(Evenement.reservation_id == db_reservation.id).update(
            {Evenement.reservation_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if reservation_data.evenement:
            # Validate that all IDs exist
            for evenement_id in reservation_data.evenement:
                db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
                if not db_evenement:
                    raise HTTPException(status_code=400, detail=f"Evenement with id {evenement_id} not found")

            # Update the related entities with the new foreign key
            database.query(Evenement).filter(Evenement.id.in_(reservation_data.evenement)).update(
                {Evenement.reservation_id: db_reservation.id}, synchronize_session=False
            )
    if reservation_data.salle_1 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Salle).filter(Salle.reservation_2_id == db_reservation.id).update(
            {Salle.reservation_2_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if reservation_data.salle_1:
            # Validate that all IDs exist
            for salle_id in reservation_data.salle_1:
                db_salle = database.query(Salle).filter(Salle.id == salle_id).first()
                if not db_salle:
                    raise HTTPException(status_code=400, detail=f"Salle with id {salle_id} not found")

            # Update the related entities with the new foreign key
            database.query(Salle).filter(Salle.id.in_(reservation_data.salle_1)).update(
                {Salle.reservation_2_id: db_reservation.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_reservation)

    ressource_ids = database.query(Ressource.id).filter(Ressource.reservation_1_id == db_reservation.id).all()
    evenement_ids = database.query(Evenement.id).filter(Evenement.reservation_id == db_reservation.id).all()
    salle_1_ids = database.query(Salle.id).filter(Salle.reservation_2_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "ressource_ids": [x[0] for x in ressource_ids],        "evenement_ids": [x[0] for x in evenement_ids],        "salle_1_ids": [x[0] for x in salle_1_ids]    }
    return response_data


@app.delete("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def delete_reservation(reservation_id: int, database: Session = Depends(get_db)):
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")
    database.delete(db_reservation)
    database.commit()
    return db_reservation



############################################
#   Reservation Method Endpoints
############################################




@app.post("/reservation/methods/confirmer/", response_model=None, tags=["Reservation Methods"])
async def reservation_confirmer(
    database: Session = Depends(get_db)
):
    """
    Execute the confirmer class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "confirmer",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/Reservation/", response_model=None, tags=["Reservation Methods"])
async def reservation_Reservation(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the Reservation class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.

    Parameters (pass as JSON body):
    - dateDebutInit: date    - dateFinInit: date    - dateLimiteConfirmation: datetime    - evenement: Evenement    - salle: Salle    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        dateDebutInit = params.get('dateDebutInit')
        dateFinInit = params.get('dateFinInit')
        dateLimiteConfirmation = params.get('dateLimiteConfirmation')
        evenement = await get_evenement(params.get('evenement'), database)
        salle = await get_salle(params.get('salle'), database)

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "Reservation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/estDansDelaiConfirmation/", response_model=None, tags=["Reservation Methods"])
async def reservation_estDansDelaiConfirmation(
    database: Session = Depends(get_db)
):
    """
    Execute the estDansDelaiConfirmation class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "estDansDelaiConfirmation",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/estConfirmee/", response_model=None, tags=["Reservation Methods"])
async def reservation_estConfirmee(
    database: Session = Depends(get_db)
):
    """
    Execute the estConfirmee class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "estConfirmee",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/modifierDates/", response_model=None, tags=["Reservation Methods"])
async def reservation_modifierDates(
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the modifierDates class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.

    Parameters (pass as JSON body):
    - nouvelleDateDebut: date    - nouvelleDateFin: date    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        # Extract parameters from request body
        params = params or {}
        nouvelleDateDebut = params.get('nouvelleDateDebut')
        nouvelleDateFin = params.get('nouvelleDateFin')

        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "modifierDates",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/annuler/", response_model=None, tags=["Reservation Methods"])
async def reservation_annuler(
    database: Session = Depends(get_db)
):
    """
    Execute the annuler class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "annuler",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/verifierDisponibilite/", response_model=None, tags=["Reservation Methods"])
async def reservation_verifierDisponibilite(
    database: Session = Depends(get_db)
):
    """
    Execute the verifierDisponibilite class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "verifierDisponibilite",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/calculerCoutTotal/", response_model=None, tags=["Reservation Methods"])
async def reservation_calculerCoutTotal(
    database: Session = Depends(get_db)
):
    """
    Execute the calculerCoutTotal class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "calculerCoutTotal",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






@app.post("/reservation/methods/estModifiable/", response_model=None, tags=["Reservation Methods"])
async def reservation_estModifiable(
    database: Session = Depends(get_db)
):
    """
    Execute the estModifiable class method on Reservation.
    This method operates on all Reservation entities or performs class-level operations.
    """
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output


        # Method body not defined
        result = None

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        # Handle result serialization
        if hasattr(result, '__iter__') and not isinstance(result, (str, dict)):
            # It's a list of entities
            result_data = []
            for item in result:
                if hasattr(item, '__dict__'):
                    item_dict = {k: v for k, v in item.__dict__.items() if not k.startswith('_')}
                    result_data.append(item_dict)
                else:
                    result_data.append(str(item))
            result = result_data
        elif hasattr(result, '__dict__'):
            result = {k: v for k, v in result.__dict__.items() if not k.startswith('_')}

        return {
            "class": "Reservation",
            "method": "estModifiable",
            "status": "executed",
            "result": result,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")






############################################
# Maintaining the server
############################################
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)



